import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { defineComponent, useSSRContext, ref, mergeProps, unref, withCtx, createVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, resolveComponent, createTextVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrInterpolate, ssrRenderClass } from 'vue/server-renderer';
import { d as useRoute, _ as _export_sfc } from '../server.mjs';
import { Carousel, Slide, Navigation } from 'vue3-carousel/dist/carousel.js';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _imports_2$2 = "" + buildAssetsURL("logo.fe4a280d.png");
const _imports_1$3 = "" + buildAssetsURL("logo-white.4323b759.png");
const _sfc_main$b = {
  name: "Navbar",
  data() {
    return {
      isSticky: false,
      isMenu: false,
      active: false,
      button_active_state: false,
      overlay: false,
      button_overlay_state: false
    };
  },
  mounted() {
    const that = this;
    window.addEventListener("scroll", () => {
      let scrollPos = window.scrollY;
      if (scrollPos >= 100) {
        that.isSticky = true;
      } else {
        that.isSticky = false;
      }
    });
  }
};
function _sfc_ssrRender$9(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_router_link = resolveComponent("router-link");
  _push(`<div${ssrRenderAttrs(mergeProps({
    class: ["fixed-top", { "non-fixed": $data.isSticky }]
  }, _attrs))}><div class="topbar"><div class="container"><div class="topbar-inner"><div class="row justify-content-center justify-content-lg-between"><div class="topbar-item topbar-left"><ul class="topbar-list"><li><i class="icofont-headphone"></i><a href="tel:+6281703106180">+62 817 031 06180</a></li><li><i class="icofont-ui-message"></i><a href="mailto:info@matter.co.id">info@matter.co.id</a></li></ul></div><div class="topbar-item topbar-right"><ul class="topbar-list"><li><i class="icofont-paper-plane"></i>`);
  _push(ssrRenderComponent(_component_router_link, { to: "/contact" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Buat Jadwal`);
      } else {
        return [
          createTextVNode("Buat Jadwal")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li${ssrRenderAttr("aria-pressed", $data.overlay ? "true" : "false")} class="${ssrRenderClass([{ "overlay": $data.button_overlay_state }, "search-option"])}"><i class="icofont-search-1"></i><a href="#" class="search-popup">Search</a></li></ul></div></div></div></div></div><div class="${ssrRenderClass(["navbar-area sticky-black", { "is-sticky": $data.isSticky }])}"><div class="main-nav"><div class="container"><nav class="navbar navbar-expand-md navbar-light">`);
  _push(ssrRenderComponent(_component_router_link, {
    class: "navbar-brand",
    to: "/"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<img${ssrRenderAttr("src", _imports_2$2)} alt="logo" class="logo"${_scopeId}>`);
      } else {
        return [
          createVNode("img", {
            src: _imports_2$2,
            alt: "logo",
            class: "logo"
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<div${ssrRenderAttr("aria-pressed", $data.active ? "true" : "false")} class="${ssrRenderClass([{ "active": $data.button_active_state }, "navbar-toggler"])}"><i class="icofont-navigation-menu"></i><i class="icofont-close"></i></div><div class="${ssrRenderClass([{ show: $data.active }, "collapse navbar-collapse"])}"><ul class="navbar-nav mx-auto"><li class="nav-item"><a href="#" class="nav-link dropdown-toggle">Home</a><ul class="dropdown-menu"><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Home Demo 1 `);
      } else {
        return [
          createTextVNode(" Home Demo 1 ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Home Demo 2 `);
      } else {
        return [
          createTextVNode(" Home Demo 2 ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Home Demo 3 `);
      } else {
        return [
          createTextVNode(" Home Demo 3 ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li></ul></li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` About Us `);
      } else {
        return [
          createTextVNode(" About Us ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item"><a href="#" class="nav-link dropdown-toggle">Services</a><ul class="dropdown-menu"><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Services `);
      } else {
        return [
          createTextVNode(" Services ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Single Service `);
      } else {
        return [
          createTextVNode(" Single Service ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li></ul></li><li class="nav-item"><a href="#" class="nav-link dropdown-toggle">Pages</a><ul class="dropdown-menu"><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Pricing `);
      } else {
        return [
          createTextVNode(" Pricing ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` FAQ&#39;s `);
      } else {
        return [
          createTextVNode(" FAQ's ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Our Team `);
      } else {
        return [
          createTextVNode(" Our Team ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item"><a href="#" class="nav-link dropdown-toggle">Projects</a><ul class="dropdown-menu"><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Projects `);
      } else {
        return [
          createTextVNode(" Projects ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Single Project `);
      } else {
        return [
          createTextVNode(" Single Project ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li></ul></li><li class="nav-item"><a href="#" class="nav-link dropdown-toggle">Case Study</a><ul class="dropdown-menu"><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/cases",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Case `);
      } else {
        return [
          createTextVNode(" Case ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Cases Two Columns `);
      } else {
        return [
          createTextVNode(" Cases Two Columns ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Single Case `);
      } else {
        return [
          createTextVNode(" Single Case ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li></ul></li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Testimonial `);
      } else {
        return [
          createTextVNode(" Testimonial ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Our Clients `);
      } else {
        return [
          createTextVNode(" Our Clients ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Careers `);
      } else {
        return [
          createTextVNode(" Careers ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item"><a href="#" class="nav-link dropdown-toggle">Products</a><ul class="dropdown-menu"><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Products `);
      } else {
        return [
          createTextVNode(" Products ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Single Product `);
      } else {
        return [
          createTextVNode(" Single Product ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Cart `);
      } else {
        return [
          createTextVNode(" Cart ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Checkout `);
      } else {
        return [
          createTextVNode(" Checkout ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li></ul></li><li class="nav-item"><a href="#" class="nav-link dropdown-toggle">Users</a><ul class="dropdown-menu"><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Authentication `);
      } else {
        return [
          createTextVNode(" Authentication ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Forget Password `);
      } else {
        return [
          createTextVNode(" Forget Password ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` My Account `);
      } else {
        return [
          createTextVNode(" My Account ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` My Orders `);
      } else {
        return [
          createTextVNode(" My Orders ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` My Addresses `);
      } else {
        return [
          createTextVNode(" My Addresses ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li></ul></li><li class="nav-item"><a href="#" class="nav-link dropdown-toggle">Others</a><ul class="dropdown-menu"><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Demo Product `);
      } else {
        return [
          createTextVNode(" Demo Product ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Feedback `);
      } else {
        return [
          createTextVNode(" Feedback ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Terms Of Service `);
      } else {
        return [
          createTextVNode(" Terms Of Service ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Privacy Policy `);
      } else {
        return [
          createTextVNode(" Privacy Policy ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Search Page `);
      } else {
        return [
          createTextVNode(" Search Page ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Coming Soon `);
      } else {
        return [
          createTextVNode(" Coming Soon ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li></ul></li></ul></li><li class="nav-item"><a href="#" class="nav-link dropdown-toggle">Blogs</a><ul class="dropdown-menu"><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Blogs Grid `);
      } else {
        return [
          createTextVNode(" Blogs Grid ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Blogs Right Sidebar `);
      } else {
        return [
          createTextVNode(" Blogs Right Sidebar ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Single Blog `);
      } else {
        return [
          createTextVNode(" Single Blog ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li></ul></li><li class="nav-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "nav-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Contact`);
      } else {
        return [
          createTextVNode("Contact")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li></ul></div><div class="navbar-option"><div class="navbar-option-item">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "btn main-btn"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Login Or Register `);
      } else {
        return [
          createTextVNode(" Login Or Register ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></nav></div></div></div><div class="${ssrRenderClass([{ search: $data.overlay }, "search-overlay"])}"><div class="search-close"><i class="icofont-close"></i></div><div class="search-form-area"><div class="search-area-logo">`);
  _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<img${ssrRenderAttr("src", _imports_1$3)} alt="logo"${_scopeId}>`);
      } else {
        return [
          createVNode("img", {
            src: _imports_1$3,
            alt: "logo"
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><form><div class="form-group search-form-group"><input type="text" placeholder="Search..." class="form-control" autofocus="autofocus"><button><i class="icofont-search-1"></i></button></div></form></div></div></div>`);
}
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Navbar.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$b, [["ssrRender", _sfc_ssrRender$9]]);
const _imports_0$5 = "" + buildAssetsURL("header-shape.27181357.png");
const _sfc_main$a = {
  name: "MainBanner"
};
function _sfc_ssrRender$8(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_router_link = resolveComponent("router-link");
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "header header-bg-lg header-bg-shape border-bottom-1" }, _attrs))}><div class="container-fluid p-lg-0"><div class="row m-lg-0"><div class="col-lg-6 p-lg-0"><div class="max-585 ms-auto"><div class="header-content"><h1>Inovasi Terkini, Hasil Nyata</h1><p>Pahami data pelanggan lebih dalam, percepat proses bisnis dan optimalkan operasional dengan model AI dan ML enterprise-grade kami.</p><div class="button-group button-group-animated">`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "btn main-btn"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Jelajahi Solusi Kami `);
      } else {
        return [
          createTextVNode(" Jelajahi Solusi Kami ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "btn main-btn main-btn-white"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Hubungi Kami `);
      } else {
        return [
          createTextVNode(" Hubungi Kami ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></div></div></div></div><div class="header-image-shape"><img${ssrRenderAttr("src", _imports_0$5)} alt="shape"></div><div class="header-animation-shapes animation-d-none"><div class="header-animation-shape"></div></div></div>`);
}
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MainBanner.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["ssrRender", _sfc_ssrRender$8]]);
const _sfc_main$9 = {
  name: "Feature"
};
function _sfc_ssrRender$7(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_router_link = resolveComponent("router-link");
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "feature-section pt-min-100 pb-70" }, _attrs))}><div class="container"><div class="section-title section-title-lg"><h2>High Impact Use Case <br> AI untuk Indonesia</h2></div><div class="container"><div class="row"><div class="col-md-6 col-lg-3 pb-30"><div class="feature-card"><div class="feature-card-header"><div class="feature-card-thumb feature-card-thumb-green"><i class="flaticon-machine-learning-1"></i></div><span>Future Matter</span></div><div class="feature-card-body"><p>Mulai dari real-time demand forecasting untuk bisnis retail hingga prediksi maintenance untuk bisnis manufaktur. Model ML kami akan membantu planning dan budgetting perusahaan anda</p>`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "redirect-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Jelajahi lebih lanjut <i class="icofont-rounded-right"${_scopeId}></i>`);
      } else {
        return [
          createTextVNode(" Jelajahi lebih lanjut "),
          createVNode("i", { class: "icofont-rounded-right" })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></div><div class="col-md-6 col-lg-3 pb-30"><div class="feature-card"><div class="feature-card-header"><div class="feature-card-thumb feature-card-thumb-yellow"><i class="flaticon-voice-recognition"></i></div><span>Process Matter</span></div><div class="feature-card-body"><p>Kami menyediakan solusi end-to-end untuk meningkatkan efisiensi proses bisnis anda. Mulai dari menentukan proses bisnis yang paling berdampak terhadap output perusahaan anda hingga implementasi automasi kognitif dengan AI worker.</p>`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "redirect-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Jelajahi lebih lanjut <i class="icofont-rounded-right"${_scopeId}></i>`);
      } else {
        return [
          createTextVNode(" Jelajahi lebih lanjut "),
          createVNode("i", { class: "icofont-rounded-right" })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></div><div class="col-md-6 col-lg-3 pb-30"><div class="feature-card"><div class="feature-card-header"><div class="feature-card-thumb feature-card-thumb-blue"><i class="flaticon-machine-learning"></i></div><span>Data Matter</span></div><div class="feature-card-body"><p>Automasi proses melelahkan dalam pengambilan dan analisis data. Gunakan kemampuan kognitif anda dalam membuat keputusan dan menentukan analisa.</p>`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "redirect-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Jelajahi lebih lanjut <i class="icofont-rounded-right"${_scopeId}></i>`);
      } else {
        return [
          createTextVNode(" Jelajahi lebih lanjut "),
          createVNode("i", { class: "icofont-rounded-right" })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></div><div class="col-md-6 col-lg-3 pb-30"><div class="feature-card"><div class="feature-card-header"><div class="feature-card-thumb feature-card-thumb-violet"><i class="flaticon-processor"></i></div><span>AI Matter</span></div><div class="feature-card-body"><p>Kecerdasan buatan private enterprise-grade untuk perusahaan anda. 2x lipat lebih cepat dari openai enterprise. Pre-trained dengan dataset terbaru. Konteks lebih luas dengan 100k token. Tersedia untuk perusahaan anda.</p>`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "redirect-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Jelajahi lebih lanjut <i class="icofont-rounded-right"${_scopeId}></i>`);
      } else {
        return [
          createTextVNode(" Jelajahi lebih lanjut "),
          createVNode("i", { class: "icofont-rounded-right" })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></div></div></div></div></div>`);
}
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Feature.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["ssrRender", _sfc_ssrRender$7]]);
const _imports_0$4 = "" + buildAssetsURL("feature-shape-1.6c92c64a.png");
const _sfc_main$8 = {
  name: "About"
};
function _sfc_ssrRender$6(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_router_link = resolveComponent("router-link");
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "about-section bg-off-white pt-100 pb-70" }, _attrs))}><div class="container"><div class="row align-items-center"><div class="col-lg-6 pb-30"><div class="about-section-item about-item-image text-center"><img${ssrRenderAttr("src", _imports_0$4)} alt="shape"></div></div><div class="col-lg-6 pb-30"><div class="about-section-item about-item-details"><div class="section-title section-title-left text-start"><small>About Us</small><h2>Ensure Human is Doing Everything That Matter. <br>Everything Else, Leave it to AI</h2></div><div class="about-content"><p>Our mission is to harness the potential of robotics in undertaking tasks, thereby empowering humanity to focus on pursuits that truly matter. We believe in entrusting machines with the routine and repetitive, so that humans are liberated to invest their time and creativity in endeavors that inspire, innovate, and lead to a better future for all.</p><ul><li>Strict AI Governance</li><li>Output-oriented Implementation</li><li>Continous ML Research</li><li>AGI</li></ul>`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/about-us",
    class: "btn main-btn"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`About Us`);
      } else {
        return [
          createTextVNode("About Us")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></div></div></div></div>`);
}
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/About.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["ssrRender", _sfc_ssrRender$6]]);
const _sfc_main$7 = {
  name: "Services"
};
function _sfc_ssrRender$5(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_router_link = resolveComponent("router-link");
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "service-section pt-100 pb-70" }, _attrs))}><div class="container"><div class="section-title section-title-lg"><small>Services</small><h2>Our Purpose Is To Deliver Excellence <br> In Service And Execution</h2><p>Our purpose is to deliver excellence in service and execution Our purpose is to deliver excellence in service and Our purpose is to deliver excellence in service.</p></div><div class="row"><div class="col-md-6 col-lg-4 pb-30"><div class="service-card"><div class="service-card-thumb"><i class="flaticon-automation"></i></div><div class="service-card-body"><h3>Robotic Automation</h3><p>Proin gravida nibh vel velit auctor aliquet Aenean sollicitudin. Proin gravida nibh vel velit auctor aliquet Aenean sollicitudin.</p>`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "redirect-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Discover More <i class="icofont-rounded-right"${_scopeId}></i>`);
      } else {
        return [
          createTextVNode(" Discover More "),
          createVNode("i", { class: "icofont-rounded-right" })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></div><div class="col-md-6 col-lg-4 pb-30"><div class="service-card"><div class="service-card-thumb"><i class="flaticon-predictive-chart"></i></div><div class="service-card-body"><h3>Predictive Analytics</h3><p>Proin gravida nibh vel velit auctor aliquet Aenean sollicitudin. Proin gravida nibh vel velit auctor aliquet Aenean sollicitudin.</p>`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "redirect-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Discover More <i class="icofont-rounded-right"${_scopeId}></i>`);
      } else {
        return [
          createTextVNode(" Discover More "),
          createVNode("i", { class: "icofont-rounded-right" })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></div><div class="col-md-6 col-lg-4 pb-30"><div class="service-card"><div class="service-card-thumb"><i class="flaticon-deep-learning"></i></div><div class="service-card-body"><h3>Deep Learning</h3><p>Proin gravida nibh vel velit auctor aliquet Aenean sollicitudin. Proin gravida nibh vel velit auctor aliquet Aenean sollicitudin.</p>`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "redirect-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Discover More <i class="icofont-rounded-right"${_scopeId}></i>`);
      } else {
        return [
          createTextVNode(" Discover More "),
          createVNode("i", { class: "icofont-rounded-right" })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></div><div class="col-md-6 col-lg-4 pb-30"><div class="service-card"><div class="service-card-thumb"><i class="flaticon-data-mining"></i></div><div class="service-card-body"><h3>Data Mining</h3><p>Proin gravida nibh vel velit auctor aliquet Aenean sollicitudin. Proin gravida nibh vel velit auctor aliquet Aenean sollicitudin.</p>`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "redirect-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Discover More <i class="icofont-rounded-right"${_scopeId}></i>`);
      } else {
        return [
          createTextVNode(" Discover More "),
          createVNode("i", { class: "icofont-rounded-right" })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></div><div class="col-md-6 col-lg-4 pb-30"><div class="service-card"><div class="service-card-thumb"><i class="flaticon-diagram"></i></div><div class="service-card-body"><h3>Statistical Modeling</h3><p>Proin gravida nibh vel velit auctor aliquet Aenean sollicitudin. Proin gravida nibh vel velit auctor aliquet Aenean sollicitudin.</p>`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "redirect-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Discover More <i class="icofont-rounded-right"${_scopeId}></i>`);
      } else {
        return [
          createTextVNode(" Discover More "),
          createVNode("i", { class: "icofont-rounded-right" })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></div><div class="col-md-6 col-lg-4 pb-30"><div class="service-card"><div class="service-card-thumb"><i class="flaticon-machine-learning-2"></i></div><div class="service-card-body"><h3>Security &amp; Surveillance</h3><p>Proin gravida nibh vel velit auctor aliquet Aenean sollicitudin. Proin gravida nibh vel velit auctor aliquet Aenean sollicitudin.</p>`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/",
    class: "redirect-link"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Discover More <i class="icofont-rounded-right"${_scopeId}></i>`);
      } else {
        return [
          createTextVNode(" Discover More "),
          createVNode("i", { class: "icofont-rounded-right" })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></div></div></div></div>`);
}
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Services.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const __nuxt_component_4 = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["ssrRender", _sfc_ssrRender$5]]);
const _sfc_main$6 = {
  name: "FreeTrial"
};
function _sfc_ssrRender$4(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_router_link = resolveComponent("router-link");
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "trial-section pt-min-100 pb-100 bg-main page-bg page-bg-1" }, _attrs))}><div class="container"><div class="section-title section-title-lg section-title-white mb-0"><h2>We Are Offering 14 Days Free Trial</h2><p>Our purpose is to deliver excellence in service and execution Our purpose is to deliver excellence in service and Our purpose is to deliver excellence in service.</p>`);
  _push(ssrRenderComponent(_component_router_link, {
    to: "/contact",
    class: "btn main-btn main-btn-white main-btn-rounded-icon"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Try 14 Days Free Trial <span${_scopeId}><i class="icofont-rounded-right"${_scopeId}></i></span>`);
      } else {
        return [
          createTextVNode(" Try 14 Days Free Trial "),
          createVNode("span", null, [
            createVNode("i", { class: "icofont-rounded-right" })
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></div>`);
}
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/FreeTrial.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_5 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["ssrRender", _sfc_ssrRender$4]]);
const _imports_0$3 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEYAAABWCAMAAABFJhAtAAAC91BMVEUAAABDi8dGjMdEjMdEi8dEjMdGi8JMhbNEisZEjMhEi8dPlcxEjMdFjMdGjMdGjMZGjshEi8dKj8ZJjsZHjcZHjMZIi8Dp9fsRQHREjMdRlMsuX4tEjMhEjMdEjcdEjMZGjMZAh8Pp9fv///9GjshFjcdFjMcvYo0NPHFFjMZRlstIjcc0Z5L9/v4HNmz6/f33/P5EjMclVoUrXIrv+Pva7fbj8PkPPnNEjchIj8j3+/0dTn5GjcdLkchHjcYgUH7q9vtEgK/j8/kRQHXy+fsURHcgUYMWR3ny+fxGjcZIj8goWoh7rtfg8fgJNm5IkMtBicU8gbxIkMsURHoMO3D7/v75/P0ZSXxDicMXRnobTH4gUYHx+PtFjccoWoknWIdEisNHjcbv+f03aZUHNGz8/f0sfcD9/v1IkMoTQ3f0+vv2+/0HNWxcm87w+Pzn8/nJ3+9GjcYnWYfq9vvn8/kCMGT2+/3i7vf1+v08gr0RRHz6/f0qe8D1+/271uoVRXYbTH3z+vw7e7MaS3w9g7/S4OwMO3ISQ31bm87c6fRBiMPK3++81ulPlMytzeY8iMQ3d68WRng3hMI7frWItNr////Z6PHz+fvt9vyszOTE2+w5d64bS3rw9fo/h8L7/f3t9fojdrxgnc620ekXSHay0OmTvNyUvN3///8JNm4INWxEjMcLOnEKOG8EL2YFMWj9/v4HNGsGMmkGM2sWSoNAi8k+iccSRn07h8YUR4ARQ3sOPnZJlM8XTIQQQXlCjsoMPHQ/h8RFjcgcVIwZUIhEkM1KkMlCisUoZZ75+/3i7fWZwOBHkc0ygsNVlsw9hcE1d7AhW5Tc6fTC2u2y0OiszOZPk8s8gbw6frk4ebTt9Pm40+qhxuKOud2GtNp3q9dams4+i8oxcKokX5nz+Pvp8vioyuVqpNI9g74ubKYCLGXn7/XX5/PU5fG+1+yexOI2hMQzWYbM3++AsdhgntCVssuZrMSTpb2CmbV7k7BCa5g3Z5crVIQBJAUjAAAAqHRSTlMA6y3zSuUGAzKeomXhZF9Z06cUHQopDgnJrCQR79jMsTk2Jvrpxb8J65VNIiH46tOlm1FDMxcF5N3ayHNtVEYwHxkQ0ryxo5eFgjw4KRv87+zs49za2cvHubmskI2KfWFQQiwq9uvp48+9tK6qqZ2ckXhramFcVEw9Lvre2sKJiX9vamhe+/Xy7Ofi1L+9r6+opKOioZCKfHlwZz4q8/Lw58ybdlw8Li1OsH0xAAAJOUlEQVRYw52YdXzaQBTHj7HCrDLrYGvZ1q2d+9a5u7u7u7u7u7sbCZGS4FLoqnN3d3eXP3ZJIAkdtLDfH9wnJ9+89+5y3D0gSN6/S8n5JQAo1Lx848oADG5afmRrobWKonzTsgAc6VK+dzgA+XqX71JZDrypSkkabVcbgN40SlcvK+9FI1R3SOVUqLEWoZuB+iVRFO0HQO12sE9rr5jFGIojYwDoqcWRIZVLNIZF+T3uxvrlEZzqDqYOQRC6FwBjEBxHp3rFtC5JEGh/APoRBNG5IWhGEGTPcN6a7iRJNAdlqxMEVRtaoyWI6vWBV1XuvLwfG5tZiioAlO1laTpYaKzfc1azsrBP4+XzC8E+C2Z1rgx8aHMPNmr5OyxhitB9RcWNRTvMZIpFq2RMIVu1GfhSpREcpngIi2mfX9yYpX1ppgjplJfFdKrkE5O9powdIAlmMdJgmdga6UCmCC5ekCny5cruJyZP9ohSZfi2bDGRZQLFhHDPA8JyBecDLHKiJKYVYJ3KHJNjBIvJJoUYbnRfqTIPLLOqguq4HAyWZo6JlrODVTVC3VXBJ7IC0CpCmQVwCs0Vw9onywCTuwaLAWWyS3Pn5aryB0FMTml+wDUopaW4hnySHD4xoZLcXExlWSNdXmRjMZIsbO3EINVAGUfvAet9SV5EFRTK9QtvKYkpIhcwTGN0xMRw7i2hQSpY41vhpaSV8rpnOCJEjAmW9nC7ljuibz6QsQZERtYDnGooxZjC0e4eNcJgXWbKm0PaNw9gNCKHGJNbya0BaC9s9kN1JNFFmDLME1MYQA2MDgoFfipLtCqvd0zByJj8wG+FSot4Yma6MEWkpUEAGAmDUUHMsYNHY2NLzzkOl/h65jOXBITpwOxYa8dGTdu2Zvy48ePXbJsWdWgsu3fVDQCzZFibAlWnrN5bLE7tUly5A6unVC3QZlirADBZV8yrOFQtEocbWnHeioL+U6pOOKX2oVMTBvkJadBntmDFpXdX79y5+u5SHF/VtUVbPyAFdnTlR7w5/fyaRm8w6DXXnp++xKMrTC6QCUQ+o1YxHvI5xaDXJ5y/fv08LE0p93hQsblVM6Q0alHO3fXksxSTI+HCRbPV6Yw3X7yQ4DClXD3pbt2/vVEGoW2idsfgyb0PjoQ0s4WkUARFKdKiS0t1fLj7hHd4lM9QTxnOd3py/+yZC2YCNyMumXFCdzP57GeBM3ua99hCh+LcHt07e+YlTqBWu1PLQFCn3YkS2KMzZ+8KU1Zue+y/lGoVhQ7qZx+SX2pJBMEt9ngGY9FZcAQhkUfJpiuiNVnxnwBFzVULupTiuIBDCkK+oi0YgmA6K8rQSOym45p4ZY5qmy64FdQi3TOlmgnm9R+/f/tFoyhmxlgMTthTTXfFPWtFeVC6itvepDjSCDiK+gjf/PrjKxqBJrFCiZesOYIqDPJFUZ82pdoxK468+sE8fX2cdjEJZSMNK5NSDXc8vlmBM6iCB+Xkc8MFi9FuRF/9ZMOdbLOdTyS1cPkYdUbLTcP9OLWHPS6/ojhbhABf018kYVjj0T9L4Sf9JUGjsZ1JRDEsXoch5GPHudee/buxca42V+2pyydSdTSijdeZrb9Pv/9i0kDZXtiNZma+yCRDyqd0A5pUg6tutDqdrujPx6NMJDAk6aEJUqBOnEmEz0yQjQma2+lHVCwA+qjT66rhBbdMUDrNlqrhZHtMcXXx5/VX/hnSAuyIyxCjSYfResMUmwxix3txysI65cQv2k5o3E7hTozBGBP06Z2K6xML95jR/4TYYKfYEBvtL2wuY27oYIjjtTDEeiHEQmigqjVJt2uf0z+mcKfOiuNo0gnGnhO2VLsWx606J06l6R889ew/upprD6/laeNzw024/CwoiqBk0vUzNtuZG3YSPqAWu9F4Q1h+wnRziurm0XDHkGpHnAgjLWpPvHgxUQeRULAySWN45oMCObU8vLrmeElw41DMiFAUYsQQjko+cpx76kHx2CrajhK33TVpkgicw5gxYaNAiCSN6bS456h0G1cj8eb3+tzDG1aSHch8R8z3xVHirz98cEsUxXGQ4qkCfYoJ7bdNyRcwAkFwo86KQFl1RhxSnDeTEy4Lvcq1iAX/auFQ0ZZzNvmCldBadZiWjQmmc2qJePjXINpshk4GXjUdTpjw15B8PYlEjNAihJERpRKvJ5+9e1LYP2f4PASMi+M5p00PNY8SjSRJabU0QZoTH2kemt6fFMLSIINzwOThfL9350wOzY20RLPFYk5Mu6FxmB5c5t8ye0rGp4Go0fy/+NPT5wzMWQBKD48V597f4k9eFRuAzDRNOFM8vXr/QQrzTaU8uH/lFj9BtaYDP1RgYTdh7m+9vXz79uW3wmIp1m1hAeCf2s57C0HeVGzp4WrAbw1ov7NPhX8hFVrs7FQG+K+QYW1A1PR1K4fHMRFlf4avXDc9CrQZFtgpnTlerx/bYMauLRO2bp2wZdeMBmNzcMfrgA/7YZsAaDNnYGxs6Jw2AGwqHPBhP0Ra1NfVIwBr6oXFNPR+EcobHebvaT+8r7Rwfl/XsvyFpS3D/aEUjZHUkfu+JMomSmOy+HNDjMnmyiwEKcUYpUrG1ReJDgrO7L6q5G3OGlajnhiTNZdqoIvfUpojbwYQed1cqlbu+28EvJCLMaCgMsKVWZDXi8yVVe57niP6cqaEBxcPq8fdXnkMVN3IXMHh7mu0b8eU0VyZrUeE27VWUhZTBrhHF3bFNyh3BokXGetQpKoI4AME5760vg6/pCLDwrn8Taa5rWwRoa5kRCWpMgtnRO6CvOMBJqXkITUiQ+TAHRXXYgoJNEVWr3gpYVobtpTkzvNfmbYQaTaPxSAt7S9mLfBIH3os+vzu9GGezNKHG3qwid2ZHRexd/qOu8WNuzsOYJOZHRuyqdaOG3xAZJNKLmteCIahF9alPwD1u2OKKuK0MzZyMACTumDNGjLpV6x6fx9p52UEhTBpZ5IiS5aVNyUoUlFISDtTFMGknSmS7AfAAi1FlMw47TyS5tPOJUVpZ5xLO8PClXbW+kg7V6fpdkzaWUtTnRvKm9E03ZNPgpdQ0LS2N0w709p2k6Bv7WCfwd6/78ojFYvlcMQCRVNob9nmio1lhdbBGxVMvrlKU0VtyJbVVvSsAgT9BQA2HXhFQpAcAAAAAElFTkSuQmCC";
const _imports_1$2 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFcAAABXCAMAAABGFileAAAC01BMVEUAAADj8fdFjMj+/v///////v4tX4tFjMcpW4jK3u7///+81ewhUoJTlcsLOG/a6PNpotJspdNDi8dIkc02gL5Mk84rXYpIjcn///8pW4jM3+/6/Pxjn89QlMsgUH8XR3pGjcgrXYokVoTH3e4OPnYOO3C10uoTQ3Y3hMTo9flBgrsKOW/I3u7X5vPr9fklVoRUl81Nk8yjx+QGM2q91uxLkcr9/v/9/v8ygMK81+sdTn/u+PwiU4IrXYo1bJwMPHXK3+8bS38SQXUYSHkURHZMl9Tx+fsmWIgxZ5VdnM5HjciXs87i8PvV6PbQ4vAbRXgOPXH4/P5Ig7gnYpxyr94VRHccTX4dTX+31OoxgMIbTH0WRXf1/PxMl9P2+vwvYo41hMM5dqqexuIoeb+cxeH2+/42cKZBd6l8mroQP3MXRntzk7UZSXs5fLY6fbdLldHq9PkbS3p7mrn7/P3+//8UQXcTQXb4/P1aodilvNKRr816teEZSHvd6/VZms43ebTW6vnk8fzF3fLM5ffp9v9dm8++2ewlVYbl8vcWRXi00+nE3e00b6M2cqUsX4s3a5qlzOORvt+Cob6Cn72brML6/f/6/f0aSn8aS35doNhdoNf////n9Pro8/n///9EjMcGM2pEjcgEMmpGj8pGjskfSHoALmggWJAFMmlCicQ+hL8/hcA9g75Di8Y9gr0HM2zD2+0NOnBIkcw7f7sJNm4RPHJHkcuesMVDisWWqcG8ydg8gbxAhsIwb6cEMGkAL2lBh8Izc6wHNWy+ydg6f7kdVY46fbkXRHpJks0DLWZmodAua6XH0NswcKrJ4PLN4e/a4+rJ097Ay9iywtKVsc1XdJsZT4ceR3kZP3Sks8icrcM+hcA5fbj7/PzQ5vfM1+J0sN9qpNFSiLssZqFge58pTX4mS3wQQHWmtMh8nL53l7lkgKNkgKIjXZcjXJUiXJQiW5OLgT8iAAAAnnRSTlMAgzYMm5sDjQf8/bEUyvuyysCXNjYwKyUNCv38zMwOsIxQOP345KaflS8s87ivgFc2Hgb2tK6YlYl3bWM/MSfxu6+tmI+Ke2A9NRn9/Pz889jV1MfEp6KblZOPioJ9Z1gwLiwgHAjb2M3KxsS6rKqKdk7+7evb2czDvr63tbSzr6ypp6Winp2GgndtaGVhRTczKP79983NycjExJ1mZrbZOxMAAAbrSURBVFjDzZkFdxNBEMdDgWDFSgsNVtyhuLu7u7u7u7u7Q25715BzyIUSSAghlLTF3d0dPgK7Z8RoSTje4//6Mpfc7a/z5mZnTffHahpXa3FBneYyDMR4vlVxzbmRfTEM6xOpvcMly6aVHaYtMrv42a5XO734TStq44alEGvEkBHoW6mGjQ1aYPXDKvNzS8KLAiUKoHB0t1YeptfihbUw8Xwf6HBENsjV97PyzslavL7i/cxO90CVu86dltBXk3RrMrFZyyY6xI2AnwVbNptQSqeJtk1tqlO5uqZT2+u0UaU2Hb24HdtU0ogbEVUImegS0cgUiorQiBtToQYyHep3QKZGhRiNuCMHjBZN/e3IjB6wIzxMxaHVMnmr2tqlmwZnytS2/5oGbTNlGryxTn/f++uHVvwDas1G84oc9dX1fHmROZ6/OTK1cxf2u19kb6OaGXIbzYZPpsstpnJVzTqcYRB6HA1Q4XxVJW6VnNDkKpYj8JEeGYVies6wuDnbpo8dU+9o6FykumPS5cYeCtImhxpfiVs6yDNZYtPlZs4SpE3n3quRebZoOeKumt85yDNZM/8ht8jt04pmjp306PTpR5/GTdoNzaSxM9U7t4uEyr1x98EJVXnyyOak9EXVg7s3QuM+/ZxmMifIwnhetG4MffI8NLJMaW+KhMR9/jbNarViZkwR72cxeA8+YXp3MyTumfsmq9udcvGYpIsXg1yluN1W0/0zoXETz1nd38nUJFEWQBuly1QjDSxJ0qXtK281JV4IlWu+R1iMkgBpJwn1Csi/WpLumcPhXrawMoEgBVri4qTgUris5WxY3LO4URYwPvZQ8BMAMtluMyrCz2PhclWySxBIwNJPGNYYClcfWdyHe0HmqiJYGAra4yJAutzikXqfqV18XKtS4mhRV3rslj8XGBnI5aD1496S65k4YjRpFdfO4OVt+2Ym5/7omIjh1ct1zVG6dOkunVKcfv6KXAZaX25Kpy7w+Rxdy1UfHhETPdFpqrxV/8vdhlbeXGZZm6ioCnWKIvXuWQYzn00CQHHPZrRxlJHibKzy2uA9yMXK9OwttqhTISpq2pQyZt69wWt+XKo7VqtFpRqFRhVqsCQv1IoF3WCeGUmSlDAuO8MlC4zg4Ti7Q0oyeI+9ijm7LViBGixpANvWqNSiFjansd4rEDPKD5LWOvJ7u5JoMr+m7HZBTCuWS3bQDvRH0YKdBdDbx4Ldzl2G8b0ivzexdcFB5UuKWFXyt9hfeYaJ/gocAQDL0DiOEwSB40kOxgYA4fI4kL+QK9WHnFljFY4iQ6T3OOSdvxYIIj0uGF2OJliKYziKxWnOBn9IpuC/sXjlGeKqQklbsHX5eC/X66lxkPIB0B4KxtaF08kUxUCcK5ljGLsAgJgPahzqea+cyrcuqIvDsLKbYyIkRVcvdxzp2p1feUZTFJXsIDgGAMBwhENg4A82IOWZM+XONbFFuerRMiNmS1kMm6zLw7tNvYaUyIZUIlv93C8vQb149R6TuYAgxNzlKMilGDGHCQLI+Wt+/+oFavAyd/0SMmNILyfvxhR/CxQI7i+w0RTNCMhfAvmLO2A8aJpV+oWvvwiD/OUXo9SI1wXGV+7HAAh2huEEF05BHqXE10MB4+/jOwPGN4N8gDibnA80zAfaRoj5QHpIHKSTD4ZfXVkfwL1sdJH0E5eYv44kJX9phgWAoATS5QqSv/rsvr0Cuu7T324mmjCxv1FA7G8C7GxItEvsb4AVYH9jLvOmRHk8zhLY39T60BHVh9q5oFYu7OaU6gMr1QcYA49AwfpAedUHI6oPC1eiBrWV+pAwp3FAPZuG6llupANqPQNyPWNhPQNiPWOVcgZQnpXpeVBsodQzN+9dz9pXNjn3ofrbAdZfKFR/A+s6DnMXBNZf1MCn/oY4XjwmKCbj8SLe4De+pTtuogpGE7TA4hmObyGNxyz3hGYBKQguAP52nL+qclFakQSAQaA8FOvPDX++Ax0lcQlFJ5N/O9+5RySpXLsryPwMD2t+ZuV/kKkWUakEBVLlK9qo/Eh+w6yQG/r8l4fzX1lazX/V+bq/ePUiIZz5+tMvaaYEVTwmGfETEsNfX6D10ElFcAnkZeB6SLmB1kOhr99OKdo5bvzDU6cefhTNh/Fjd6l3Qly/ab/ejA3GzeG37i4djBv7L9fz2u8/TP+X+yXa7+8c0WWoMPaj9jSqGfr+2fqM9s+qDa2o0X7ff74/GbCf+p/v/7b33a+eotF+dZMJ/vvr23SanAc4zdaBBvU8wOp0anIeEBnn5DH1/ELXz43OL7Q5b3H7nbfE6//j86HA8yztz9/idZorsm8C/y/OCw0DeR5rbdBprqYta8X9+XnsT6GM63agV87KAAAAAElFTkSuQmCC";
const _imports_2$1 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAABWCAMAAAC6hDXPAAAC91BMVEUAAAA5hsTp9PlLibqLuNylyeFDicMjVIIrXowTQ3gZSXrb7PUGNGsdT4InWIZFi8ZCgLQfTH7///8JOG4QQHUPPXL0+f0dTX3l8/hBiMH4/P4uX4xGjcVLkMgfYJxtptIJN24INm39//8INm39/v78/v77/f0WRXoLOm8cTX4sXYvw+f0uYI4hUYIoWojV6/XX6fQ5frlEjMcOPXIYTocOPXEGNWsTQ3YUQ3dIkMogUoMaSXlCicT0+/04b5zo9ftDjMgEMWkPPnQ+isc6hsRGjsn5/P1Ij8o/isY3dq4DLmVHj8j4/P0dTX/3/PxAisYRP3EhVYjt9vs7f7dHj8euyuJEi8bk8vnx+/5BiMPs+f1cmsxup9MpW4m2xNM5hcQ6hsQbUIk6h8U+hb8xcaoiWpC30+o6hsR0qtURQHO+y9j3+/2nyub4/P33/P0NPHBFi8WZweAcTIAgXJQcTH3t9fny9vm20ukxY5H6/P7///84cJ8+cJmSp756rdYwcKr///8oZJ7g5uxFj8rH3vCUvt7q8fjF0d0jZaI5fLb1+vw9iMQWR3mHtdojZaWRvN3B2uyOqMBDisWRvN34//94rNeQuNuWr8fO4uz///8JN24INWwGMmr+//6Lw95EjMcGNGwDMGlHkMx0qtUAL2gAK2WXv+Cwv9E7h8QTQHUNPHRGj8ro8ffi5+2x0eiOxuGEv9zW5vM+ishCicMta6UXTIUNOnE2ebMRQnoPP3f6/Pzy9vrD3e2aw+UaUIkKN2/2+fzu8fTO4e+TzOaSyuSVvt9Iks00drEeVI0bRnnj7/a71umWzeaRvN6BstlVmc9so8RviqoraaM6XosnUoPt9fre6/TT5PHa4um10uikyuTO1+KdxOKHwd6Jt9ymt8o/hL9ZjLPj6e652+zX3+h/t9R5r85jos44h8c+g70ac7xaj7QiW5RIapMmVokxV4YYQ3Z3tNq/y9m2w9NUms2Yq8Fil7t/l7NKfqVjf6MkZKBDdJ87bJgEQTWmAAAAmXRSTlMA/loLpgUwCA+7PBrooSgbGP723tTKjGJXSzIvJhD+/fz37+7o2s7KmHViYVJGOCYf/vDpv7u4s5+VjldTKiEQ+vjf3NPQysC8u7KoopiVj4WCf3VzZWFOQj47OiAW+vnx7uXl5M7GxsTCwby7uLS0srCpppGIbm1sWlVDNvDs7OPj4uHe3t3bysm+uKejopaQi4Z9cF1HRTUzcSPWAAAFy0lEQVRYw5WXZUDUUBzAH56IdItYiIqKYHd3d3d3d3d357Z3MbyhcurhqQciSquUgmB3d3d88L1tt925m979PrDtsd9e/9//gAxV/P0CgF0UbkFRCcXtUjwokiQr26U4OUNY0wvYhVcD9+LATjwLAXsp0d9uZdBAYBdV5xSZO7fLrgHARop3m7o4KS6kfNzpIc4VbRlol9rBFEWnv8vLe+etgWTCfxfB4HqlKRIBaQQkMdT4Kv8yqvlBUgLVfK+8UWzFIQ0pRXsgTNZYdkRGURa1bjiWJ+QUokxVICGwfrtxhEmhhG6YFGJru7Z9LA1FDbXDfpNCnTLyUmyCSSnooFZbroeFzdQHTQp8rY6JYo0TuhOUqOh6Wuyo4TpR0cScO3cSosqijkccP0UJSsTlhkCk88kIM+V8hI5T7uuOx5or/kBk/FlblBPBTcTg4GabAl3Ene6LFElfSLEvUgU488pDYcQodsTUl9FVVMoOFpVuvJKUDi3m5RQ3lZ/47tc1X/OjuUGOy6els09FXeeUUYuAGU24qSRyGStLLE/JzX4jyyU5rcawIKRcj4KS7cKgrhCbh9Vo7QUsHU/PPQTiHk1bGhomF5f39vRUAAmNlayTzmjMq6C+4WLlAus7jFWI6z/eM4yWhhBqGSbhzUcCI69wHLmX+yY//b13Xu6XW3yRcr71XTmFEElMSjotPilDXIFVXNsQMpRDcVPOUVo3+gFZmnYhCImlnFwV/It+E/8WQsLA/+jbqZxSeL/M5PlNgQ00LRY24dbjx7eGzBngCmymA2U0UmUVANihoMCvtUcp2WddKcTPnjYcsdWKFkAUnZR2hiVyNXpGNJY3ipYjrOLTQ+7Y3o0MGXpbb+LYbEKWo0OtOq0iCQmnkzM45WB/qeDSfYRUybxkiIiMw4phZkMnS6FKXRjrgJXM7Eie7GTimqF6qfPPb7LKBdq/obkRWloDa7G1ZFw7xnPtCnHX4SRDxlxKxMro5hrKXayoAQX9XRQt03DjDwskIiVWC8+zysFAj7oaTW0Fb8yDmnrIH4uVm0H7eYLiifjnMSdPOGSbRiyUgu6csSiYuys0HS93MwhlpNpg2I9jwJhA7tt0JS7swwpcfX0JCVczk9nNM5s/7eiahXFiRFJ8OlSAkKUInz7WZKtpACsAWxXQGfo5AacWmu7yyukbGUpzZSFV2gN4lCaryCtHX140rwVXUBm4kLhHst2/GC8qmLowFIQLXQHFCFmEDVMPTUgAVVsIlmUkr165fQxfxOSqYkIdEEDWASY2yPWljKugoNcraZwFZbZEOXw3GV+mAFGZCipDP0chPfaROFyMLiAo7nQDNGJlCwsFXQirlHcUkwpNKJoXWvwJMTDRqrITCPjCcJTyGLcLcapRmjUjs6swpr29m3sA1wkPcbLpxCkHb0uNeDWnoNaVJ5LW7gOdcOmkLb6BChzKmjmkxf1l3FAberHbyb9WQfwcAnqwM9beeWTrkqi8foQhKBmPkrhiDLq27H9q1Jq5CpdM5BIEn2rAqw+7z9rH6D7fPsbXpMw4+uxc9aVebJsLAccQXBgGHNljuJ9wShif6KOjs44+io9/dOPmnWiVPt/NNAnVfLivgzA07mMGmZQ6xqd6lepONMsdlUqlfysojtPX+BCd8E2BJYN6tXM0rVQ6J1Vlhj463dcUvXZsVIzb1pQLxoFgeQU+TAcw31Pwm6mpqSl6dJOaAzfxB4P7BU9FS0/A0r4nCHBuyY4LaALzVXr07VcPXj3ATUz5zYQDTNeVtbqBQqP4nMwfb7KSaGIwM5gHWaqsXwxNM94qfUpOgi/Xlf4l0J/usAkfw9d3FA/S4sHGnKwPb2mcUz5LeeKtrQQEerUKF47TjiWAQCVt1NdLZ7mcP8ibmQUEFB3ljtvQYOrFBaycehFLV3QCtuBSuzqnVPdrCGylNatEjSwMbKb+cKwcmgbsYAZSSPtymHBfNze3WcAqfwCWJ9TFvgkxpQAAAABJRU5ErkJggg==";
const _sfc_main$5 = {
  name: "Process"
};
function _sfc_ssrRender$3(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "process-section pt-100 pb-70 bg-off-white" }, _attrs))}><div class="container"><div class="section-title section-title-lg"><small>Our Workflow</small><h2>Bagaimana Kami Adopsi AI dan Machine Learning ke Dalam Implementasi Bisnis Anda</h2></div><div class="process-content"><div class="process-content-line"></div><div class="row justify-content-center"><div class="col-sm-6 col-lg-4 pb-30"><div class="process-item process-item-center border"><div class="process-thumb"><img${ssrRenderAttr("src", _imports_0$3)} alt="shape"></div><div class="process-text"><h3>Planning</h3><p>Kami akan mengadakan process mining dan audit untuk membantu anda melihat bagian mana dari bisnis anda yang paling terdampak ketika AI di implementasikan.</p></div></div></div><div class="col-sm-6 col-lg-4 pb-30"><div class="process-item process-item-center border"><div class="process-thumb"><img${ssrRenderAttr("src", _imports_1$2)} alt="shape"></div><div class="process-text"><h3>Design &amp; Execution</h3><p>Perencanaan implementasi berdasarkan proyek, analisa resiko dan desain sistem akan dibuat sesuai kebutuhan bisnis anda. Prototyping, iterasi dan eksekusi implementasi akan dilakukan secara real time dan kontinyu.</p></div></div></div><div class="col-sm-6 col-lg-4 pb-30"><div class="process-item process-item-center border"><div class="process-thumb"><img${ssrRenderAttr("src", _imports_2$1)} alt="shape"></div><div class="process-text"><h3>Report, Support &amp; Signout</h3><p>Setelah sistem berhasil terimplementasi, kami akan memberikan dokumentasi penggunaan lengkap untuk perusahaan anda, training dan troubleshooting support</p></div></div></div></div></div></div></div>`);
}
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Process.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_6 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["ssrRender", _sfc_ssrRender$3]]);
const _imports_0$2 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAaQAAAGkCAMAAABJkqEHAAAAolBMVEUAAADy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vPy8vO2ZRX8AAAANXRSTlMA++9i3JEVbiSwHAL0NgvKEOrYf/KfmWn30ujiWo56DbyJVUYEzk9BdTsrp5QZtkq5KAjDL4kQtsIAAAwCSURBVHja7N3ZdtowEAbgMQZjMNjsZt8DgZSwpPP+r9b09LQ5TUJisGWP5P+74l5HaDQzGpPWPGe/Gpfbk25lHgTFUaFQsPiV9fpjVAyCeaU7aZfHq73jEaStUV8+lirBkCMbBpXS47LeIFBufV62n4Im360ZPLWX5zWBEofj9GlgcSKswdP0eCBI0Gw7rYw4caPKdDsjiK867g0sVsYa9MZVgvtV7W6RU1Ds2lioe/jHUotT1CodfYIbuOWTxamzTmWXIJL6osWZaS3qBF/zdpMRZ2w02SFBcV19MmQRhhPsp0+57SILUmzjfHrHt19YnBcb8d6bXbfGItW6O4JXs/CBBRuEyBzte0I30Ztab095djyxFk5HyqlL2GJttMIL5U9j2mStNKd5K+seFh3WTmeRpzrhodRnLfVLeVmmqq5L9GeZ8lB5ciYaL9Fv/YlDZvPbGp5F73XaJqeL1qFmEd01zdDYprCNqDR3PMUNmejnnI0y/0mmcXpsnJ5ZEcQ6LLCBCiYdTTvRxYg4HkypNzUM/Kd70zMiozcW0lyiynBMuqs+s/GeNc8U2UYGDO8VbNJX1bCr0XVzbfu/bAPydFF19DyZnArnypOGYd7G8KDuo5Fud6ZLifPHWmiVgDgbm2L4WqBR/GCLb3hUpaZLMO53Ocd6WvTnuTn9q/sr0CD/sMzR5ehzzS3J5i0YrEeSrJGDdGoUFcHPZc4adeCr1TqTUKtcpLyjKaxIpLLF8I9VJnm8Hwz/+SFuGoSPkOGDZ2HdyE7A8EEgqjHPNaiBOElFQQnXuiF9+Mlrihl/s819Jui6mpAc0UbzV2Fq9UU8v7BxPfqSJaDEFDJ8I6SMlRm+VaZMPTJE8EgZmjJEMqXIsI+iM2Uv4TySfy4hrpO/SjbDTWxK3QZ32BtZG0rZFmt0M2tLqarntpE4jlqdUuSiNnGXpkupcVDju1PRoZT4qJXfLfApFV7O3lkmq+JRGtC7FcsPugaJBjlCUm6FC1JM1pEUO6PfO7bCnpRqIPhOQLFBCnloJk7EySN18I4vIQtSZsmQkCUp4iJoSEzBJSX8nL/9T9aDTyrkeoZG8rr0D8rlYtmUuDPKfAmrnSlhFxxIiXu4ULLyOL/uCrEJ8SODAhtKkJO7WZ3pGDqUHNRiFakg+taATQlx8XBZmY5LycjNnPwszPFnpwGbElBF7lupQpXiQzFWsWeKbcyg2JhiauAaq9ywQfEY/T0+KXoUy44hBTuKwUOBIhUPHq5I8pXpbjM86EtJwaF7TRiukxE7uHhAkZ46qkjyvdBdVgwp2tAd1gOGFLXWmMElXxnht3zNGd2qzZCyNt3IQV9D6joO7rHyTegmVUzNz0C/itZv+Up0gwM2Uib6B2wk+UrYSPL1DxjXIN+CImrgjpSZTgNfoJBvSpFc0GqXoeYFUwflCykKfGU+Uy0UZDWwou+dGDJ1om/tGTK2R4e+fD36ho8RQpmrzRB/yxfS19DHJcAA75E0sMN0SPm6CBvkq/l4NCafTde9MIjwQle5DEK4aC2Wr03X4JMuYhTpijqDGHV028lXok956G0QZOghJSTfFv928v1i715zEguiKApvUFBAQCHYQXyiNiidaKI1/6m14oNHq3973WR9U7iJFlX77NPIVyZFIBPPdhXQNQDOd2Xcjm/gvV0F7NutwbdnJpLvMVt6Dvfh1C7cYsX34HUDX8MDON8gG9pFQG1jQnw7hiL5RqYb+Hb9l1QBbZck8Z063sd3nBWXu0Dd5lPPfQdQtV4+zIqgZjY+8Z27OYSvZZiLb5J3zSKsppVPfNd5My/CmufNoghrYQsK3zhLN943gNVubLjju8+raRHY1GIAvqGHO75FXvWLwPp5VS8Cq+fFYRHaobOyfF1P4HxTr1f55g698DV8O+dr+TOJr5/kqAjtKOn4UEHXMYXC18xzEdyzUSG+a0eT+E7tFOLb812Wb5izIrgzywH4Rl7d8bVyWQR36cokvieD4HxjC2v4Bo5i8k1M3fHV/Uh8fqQKqMf1v3gHKcLzI1WAH6kC/EgV4MGB78AjOJ+/kyrAj1QBdS9Y+SY+VfANfPTjG/t8zvdkEIXv0kgXX8twJN/ImDHfmYF9vqGjL3x7DpHxnTqOyXftYDPfsxUBfE3LNvg61tbgHVkAxde3So2vZSkhX8N6T765Rbl8Uyun+bqWt/MdugYBr+5CEb6+q3n4Fi654hu6Lo5v6uJFvntXmOLVblwGjDd2rTbfwgX1fPMsGRgiu86SWRSyZt44ksk1yZIv6GStfDgvgjrPh1kR1Cwfet45QNV6+XRbhDTOynER0nE+OaREdZqVdhFSOyuW1zDtZo1FAUyjrNspAtpJ/KdE186GQRHOIGscgGH6k00PRTi/s+nC6zuc2kW2PBbBXGaLHUM8e9m2XwSznxcewtEG+ddVEcpVtjg7y9PNGoNdSJMseelA1sgaM0NMs3ylc1KEcdKJf+/oGnnh+Y6tmzUmHZB28wXLAliGeef9Hdd+vuMyJYqnbDA0RLST7/VcDYxwcJFNhiR5RvnJXRHAXb5hOwrGOD/7VfTf/W3vXrvTBIIwAL+AooIXvBvvGoOt0Rht9///taY9bU6bKAWFZYD3+eT3PSuzM7OzQwRbMHRI3ZWwgZf+JBkgAKffybDDJ+ySFOYVATgOSoZHfMIGPGE6+IVRuGRDhHFmr0OK2mcE4TwoCeYIx+spSknPwyVsC5dkhbAOI0WpGB1wATvwRCkD3ErCjQ4At5Jwe0ThcCulYOQgkpki7WaIxuZZSbuejcvYcixHF1Et2oq0ai/wP5y+kbYKotuwu0urzgYfsUQrjY8o+M5IGr7hNlWOV9OngXc80Qo1wG8Mw8UybQTjpbL0VXA7l8/BaPHkIhjvK6XvKwKxf1+AAe7jsQkvcWMPt+DTSjpNcbcXRYl6wf0cU1GCTAfveFgSykIslooSs0Q8qux3SEyvijf8wxPNwgWsLIlSQ3xsHmkTMbYRI19RAnzEaq8odnvE68yiReyezojZiUOHYlY/4R3jcKEs3IhTJbXpIwlNtrTG6KGJRFSZDxeYDvporSgma0TGAQ+arZAcl2XaWLy6SJDHh2FiUPKQqB2Dh7uZOyTsyKsWdzKOuAdnFuowxFVMiAuxhw4u67R3qLnQotlSdKNWE5rYDMRvVLKhTZVXAG/SrkKjBkuAN6g3oNWWx6XIjC0087lKERk+wmI5PRrh5XJOiPpJxAVzrtJFeVkj4IuikL4gAXzVIlZzRMC9FE5+9hG/S9K/RywvySogBbN4qg1kWBDA5zT+ACMfImyZbb2qvoUQDVYurmg3IEaVVcCLSlUIYrOifkHLhihNNiB/8tKEMC47vT7YbyBPhQemvxippxkuO3IG0bveEULtGOT9VtpBLI/hwy8vHgRzeRfwzcqFbOvCf5h6a4hXLfgkgQdRWYZrmoWeytEXd4K9wipsWrwuongUzqmgf3mtTPzV/XEuYpLIWElMBAXxC1djmnxF5tgFu7X5LPoAe5VVoCNTb4qMcgozm3+ZqYjhA6sQA1TMDAXelzgFSLm+OMi6ac4Hv48z+zX6m5frdwEH2QzqPvua26HiTxk8G12zGeYygDCHWUsxBLNz+J83ENZWF4PvOTs0Lb8jj/wc9amUhFyWiN+mkpOsa7uSr4/RvxbdHOTzet0F8s2eZfzO2WiWv3jhM2ef4WUa7bOfAwrHKWd0mUbloizRT4dZBr9NvdkBxeLNMxbpted5ydJFcR52VGZ0hmcUk3t8VZnwepTe3Z2o3UB8I2V9IPgeiyaLoehOyodh3k+uIX3tC91O9X6O6kV3a1rflDjfrKw032tz6opKkpe6J9AFjbKQppVxWdC4GXHcbXmiUjYpbwsdcIfSWHVUajor7qGQqpWlobQzlpUsdwunoOnvtW6ozt5nLHcLx+qXlAalvlWkEkT8nOngwVCJMR4GUy5QHBbbeW2iYjepzbfM+cTKfpw/dwwVC6PzPH8sQqtCKjandfe5Zaqbma3n7vqU54YsMbzG+ku59jRWoY2fauUv60YRi6tpcw+7x2mlO+vXlq1WaWKapqHeGG8/JqVWa1nrz7qV6ePukO0Uwg8aFvVkHbCsFgAAAABJRU5ErkJggg==";
const _sfc_main$4 = {
  __name: "Testimonial",
  __ssrInlineRender: true,
  setup(__props) {
    const carouselItems = ref([
      {
        id: 1,
        title: "Energy Production Demand Forecasting",
        desc: "Implementasi Machine Learning memungkinkan PT I mengantisipasi produksi energi dari sumber terbarukan yang tidak stabil. Model ML meningkatkan keandalan suplai listrik, menghindari pemadaman dan memaksimalkan efisiensi operasional dalam aktivitas pengurangan dampak lingkungan.",
        image: "/assets/images/testimonial-1.jpg",
        name: "Power Grid",
        address: "Indonesia"
      },
      {
        id: 2,
        title: "Supply Chain Demand Forecasting",
        desc: "Perusahaan Franchise Ritel terbesar di Indonesia menggunakan model ML untuk memprediksi permintaan produk dan mengoptimalkan persediaan di setiap gerai. Model ML kami meningkatkan akurasi prediksi permintaan produk hingga 30% dan mengurangi biaya persediaan hingga 20%.",
        image: "/assets/images/testimonial-2.jpg",
        name: "Retail Chain",
        address: "Indonesia"
      },
      {
        id: 3,
        title: "Marketing Campaign Optimization",
        desc: "Analisa prediktif kami membantu perusahaan asuransi meningkatkan efektivitas kampanye pemasaran mereka dari sales history dan 40 faktor variable kampanye. Model ML kami meningkatkan akurasi prediksi konversi hingga 40% dan mengurangi biaya pemasaran hingga 30%.",
        image: "/assets/images/testimonial-3.jpg",
        name: "Insurance Company",
        address: "Indonesia"
      },
      {
        id: 4,
        title: "AI Backend",
        desc: "Sebuah startup unicorn di Indonesia menggunakan Rancangan Foundational Model dari AI kami untuk membangun AI backend mereka. Model AI kami meningkatkan kecepatan generatif aplikasi hingga 200% dan meningkatkan kepatuhan respons terhadap instruksi 37% lebih akurat dibandingkan produk API ChatGPT 4 dari OpenAI.",
        image: "/assets/images/testimonial-4.jpg",
        name: "Startup",
        address: "Indonesia"
      }
    ]);
    const breakpoints = ref({
      0: {
        itemsToShow: 1,
        snapAlign: "center"
      },
      768: {
        itemsToShow: 2,
        snapAlign: "center"
      },
      992: {
        itemsToShow: 3,
        snapAlign: "center"
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Carousel = Carousel;
      const _component_Slide = Slide;
      const _component_Navigation = Navigation;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "testimonial-section p-tb-100 position-relative" }, _attrs))}><div class="section-inner-center-shape animation-d-none"><img${ssrRenderAttr("src", _imports_0$2)} alt="shape"></div><div class="container"><div class="section-title"><small>Klien Kami</small><h2>Customer Success Stories dan Use Cases</h2></div><div class="testimonial-carousel default-carousel">`);
      _push(ssrRenderComponent(_component_Carousel, {
        autoplay: 5e3,
        settings: _ctx.settings,
        breakpoints: unref(breakpoints),
        "wrap-around": true
      }, {
        addons: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Navigation, null, {
              next: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<i class="icofont-arrow-right"${_scopeId2}></i>`);
                } else {
                  return [
                    createVNode("i", { class: "icofont-arrow-right" })
                  ];
                }
              }),
              prev: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<i class="icofont-arrow-left"${_scopeId2}></i>`);
                } else {
                  return [
                    createVNode("i", { class: "icofont-arrow-left" })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Navigation, null, {
                next: withCtx(() => [
                  createVNode("i", { class: "icofont-arrow-right" })
                ]),
                prev: withCtx(() => [
                  createVNode("i", { class: "icofont-arrow-left" })
                ]),
                _: 1
              })
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<!--[-->`);
            ssrRenderList(unref(carouselItems), (slide) => {
              _push2(ssrRenderComponent(_component_Slide, {
                key: slide.id
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<div class="testimonial-card"${_scopeId2}><div class="testimonial-card-body"${_scopeId2}><div class="testimonial-card-inner-header"${_scopeId2}><h3${_scopeId2}>${ssrInterpolate(slide.title)}</h3><div class="testimonial-quote"${_scopeId2}><i class="icofont-quote-left"${_scopeId2}></i></div></div><p class="testimonial-para"${_scopeId2}>${ssrInterpolate(slide.desc)}</p><ul class="review-star-list"${_scopeId2}><li class="starred"${_scopeId2}><i class="icofont-star"${_scopeId2}></i></li><li class="starred"${_scopeId2}><i class="icofont-star"${_scopeId2}></i></li><li class="starred"${_scopeId2}><i class="icofont-star"${_scopeId2}></i></li><li class="starred"${_scopeId2}><i class="icofont-star"${_scopeId2}></i></li><li class="starred"${_scopeId2}><i class="icofont-star"${_scopeId2}></i></li></ul></div><div class="testimonial-card-info"${_scopeId2}><div class="testimonial-card-info-thumb"${_scopeId2}><img${ssrRenderAttr("src", slide.image)} alt="testimonial"${_scopeId2}></div><div class="testimonial-card-info-text"${_scopeId2}><h3 class="testimonial-name"${_scopeId2}>${ssrInterpolate(slide.name)}</h3><p class="testimonial-address"${_scopeId2}>${ssrInterpolate(slide.address)}</p></div></div></div>`);
                  } else {
                    return [
                      createVNode("div", { class: "testimonial-card" }, [
                        createVNode("div", { class: "testimonial-card-body" }, [
                          createVNode("div", { class: "testimonial-card-inner-header" }, [
                            createVNode("h3", null, toDisplayString(slide.title), 1),
                            createVNode("div", { class: "testimonial-quote" }, [
                              createVNode("i", { class: "icofont-quote-left" })
                            ])
                          ]),
                          createVNode("p", { class: "testimonial-para" }, toDisplayString(slide.desc), 1),
                          createVNode("ul", { class: "review-star-list" }, [
                            createVNode("li", { class: "starred" }, [
                              createVNode("i", { class: "icofont-star" })
                            ]),
                            createVNode("li", { class: "starred" }, [
                              createVNode("i", { class: "icofont-star" })
                            ]),
                            createVNode("li", { class: "starred" }, [
                              createVNode("i", { class: "icofont-star" })
                            ]),
                            createVNode("li", { class: "starred" }, [
                              createVNode("i", { class: "icofont-star" })
                            ]),
                            createVNode("li", { class: "starred" }, [
                              createVNode("i", { class: "icofont-star" })
                            ])
                          ])
                        ]),
                        createVNode("div", { class: "testimonial-card-info" }, [
                          createVNode("div", { class: "testimonial-card-info-thumb" }, [
                            createVNode("img", {
                              src: slide.image,
                              alt: "testimonial"
                            }, null, 8, ["src"])
                          ]),
                          createVNode("div", { class: "testimonial-card-info-text" }, [
                            createVNode("h3", { class: "testimonial-name" }, toDisplayString(slide.name), 1),
                            createVNode("p", { class: "testimonial-address" }, toDisplayString(slide.address), 1)
                          ])
                        ])
                      ])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]-->`);
          } else {
            return [
              (openBlock(true), createBlock(Fragment, null, renderList(unref(carouselItems), (slide) => {
                return openBlock(), createBlock(_component_Slide, {
                  key: slide.id
                }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "testimonial-card" }, [
                      createVNode("div", { class: "testimonial-card-body" }, [
                        createVNode("div", { class: "testimonial-card-inner-header" }, [
                          createVNode("h3", null, toDisplayString(slide.title), 1),
                          createVNode("div", { class: "testimonial-quote" }, [
                            createVNode("i", { class: "icofont-quote-left" })
                          ])
                        ]),
                        createVNode("p", { class: "testimonial-para" }, toDisplayString(slide.desc), 1),
                        createVNode("ul", { class: "review-star-list" }, [
                          createVNode("li", { class: "starred" }, [
                            createVNode("i", { class: "icofont-star" })
                          ]),
                          createVNode("li", { class: "starred" }, [
                            createVNode("i", { class: "icofont-star" })
                          ]),
                          createVNode("li", { class: "starred" }, [
                            createVNode("i", { class: "icofont-star" })
                          ]),
                          createVNode("li", { class: "starred" }, [
                            createVNode("i", { class: "icofont-star" })
                          ]),
                          createVNode("li", { class: "starred" }, [
                            createVNode("i", { class: "icofont-star" })
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "testimonial-card-info" }, [
                        createVNode("div", { class: "testimonial-card-info-thumb" }, [
                          createVNode("img", {
                            src: slide.image,
                            alt: "testimonial"
                          }, null, 8, ["src"])
                        ]),
                        createVNode("div", { class: "testimonial-card-info-text" }, [
                          createVNode("h3", { class: "testimonial-name" }, toDisplayString(slide.name), 1),
                          createVNode("p", { class: "testimonial-address" }, toDisplayString(slide.address), 1)
                        ])
                      ])
                    ])
                  ]),
                  _: 2
                }, 1024);
              }), 128))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Testimonial.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_7 = _sfc_main$4;
const _imports_0$1 = "" + buildAssetsURL("blog-1.fdc6778b.jpg");
const _imports_1$1 = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wgARCABQAFADAREAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAABQYEBwIDCAAB/8QAGgEAAgMBAQAAAAAAAAAAAAAAAgQAAwUBBv/aAAwDAQACEAMQAAAAtPO03Oys1bVJ7M+QqwrnJjJlJ6TmzJ25sk7kqYLUDhPKzHUWnkmW0tfOy+8oFDS2dBO4eunQsEWJS5BBX9qZjIVewpzYrexToHpyV32mljfWZ4Ir6uHFgkCFDouPdEeDNjExEVdsEwXahp5rI+yTiE5nuTedw7AjBMJOnFOb4qCgYTmyRyFnaUy7Ea0KrC28W6x2pkNWBrek1yDqikzoHRTE6VjjbxGfyqVYRs9Bu3vO6+S98Csq538qqvR5HUKPoY3a+X28OCQyOxnAn3HefvMbnNfuvLNFt3RimzRjWZVViH2T50fchKk//8QAJRAAAQUAAgICAgMBAAAAAAAAAwECBAUGAAcRExIUITEIIiQy/9oACAEBAAEIAKi/QJEjLQ3nkKvVmkE6M8godz7YaH4PR1CmQDmPa9qK38c+TfPP3+vHATUDI/suhkAJ9fkGfIiVhjc2HZN5rK4lDh0yPYgie8+A7S1WLtI9fe53VCsYzDoK4iu8ojr2MMqMUFkwv5ZXR6Y5VGaQNjF8xu6dJNg9fHhp1RVxqPLxAjhqPynwnUtVf15quwxco1PTya0obWW6WZViyklRQk5KtZFYP5BDLIWQjiVdgYMlPZ2jKNdRYcbmyrNP9gzIWDzuknYKwHN63pdrEu0WXrwFgba2MWZoo6FUwnbqzeX4AjbWS96/eo4diUiEayPMQj0ICIVtyVCslM9LyOyNvqQzjQUoZSFREf260RjzgQ4tLNM96cNTzhTRReSs9PDEeRYFdaxRINGQ7B6+XOppjprTrbXK189Kuwz1VRCOw6Z+2iQbQ0CBrmT0vpaHgR5I0fySGSsoTuSmHfHexWehUTywcZefVE//AI7gz8efURnFg194ByAN1fQMqgLf30Ls2BtNdNe9AMTnpFxwGKnByP15YVq81O2p82j2SdDIv7m8p4C4fNUEaK2xi/yS1igggyMME0sT/QHr3tKYIYoVzX2sKyjoeCQ7ODRip+e0NwernkoaZbL6Z0nuxNP7bG1vbPYTo2X913Gv7eTb2ky4sXJG9iPbEI5i+Uzmmsa4jVjUfaCEVA2YCCTx87qydcaW2tB9K1LLfcEKauEyqpQRRd9aX7MsedjOcjGPcoBKMfkiv9bHrxhnJ+6sKz0eJn//xAA1EAACAQMDAQUFBQkAAAAAAAABAgMABBESITFBEyJRYXEFFDJSgRAjQmKhJEOCkqKxwcLR/9oACAEBAAk/ADIy1qwOPSnz2ezeVFSp338K9o2SyHlTcKD+ppwwPBHBpqP2iME9ajbS/DijiGXJd24A6k1O493mIlK5Jl/wBUL3rZ1Ee8bZFWl3ZQSuEBmDGFj0BJJFFTHIMqR08jUy7VMuTUufSrxVlG53GanjlRD3Rnmk7FrmWONHB6ZJNRhHmAlmfG5J3GTUyEt0zVrFcQXCtGwxwSNiD4ip2kltpDoZzltJYqM+hFXLBV/U07Z8albUN8U8jknc5qeURHpmp+1VL6EaMHU6k4Y/QGpXEKj9nUTMgY7AKAo2GOpq8lX2msmIJATlVq8DRIVIExkEpbrvnSRWRaXLQLEq4wJCGcluoU4xt1p10qRhPGtMUea0svQjioGMecA1BxtTtBFJECHxnDBgRt54IoqDjIJ6VeWi2va90Nbg/dk7rznJHB+tPqZHxrG24NEj2hcdkJHHCRqu31I2rch8E1zJ+LFTKcDjFJtnNJuedqHdUYIq2dCz98bjUhGAynqDXuXYb9xogzHb5jvVrojmkBhjXONR5xmoO+CB9MDFWzAk1bMcdcVC248KFaaK1s8bsIpV+KNsZGDXtjEIOVAHfOdtyaJhWKIuDc7MsajJLfKpG+OcVELe3mdYrAHY9mowpbwLUMV/atP8tDmutTG5ugMi2g7z/U8LViIUSyeb2lEHytsZBlMnliNht50Te3inS8twgDwt8oThfI9fGpe/Ppub8qf3fKR/xEZqZUfQWQ53J4AFYuY1wuTs49DUqyoRkjhk9RSUMUQlwsamefllLjIVfA43JrXLJDKjnHeeR9Q0qB1YnepZZLmVI7Mh/wAgDOxHzFjiiqCCLVcIfglQfhIHUk4HUGpGNxdymWRuQueB6AYFRL7wRqZvBeBzwT5fZcsrj4TnFQmVurrhTT4zz6UCTc30hjABJIB0LgDnYUMWfsmzeWRyNxO4Cpj8ygk+Rp3KICxd/iZm3JOeu+9S9RcXhH9Cf7UM4GAB1J4FNmRjlz5/8rijuenhUskT47rryD6V/8QAKxEAAgECBQMDAwUAAAAAAAAAAAIDARIEBRETIiExMhAgUSNSkUJhYoHh/9oACAECAQE/AFKVtN8WbiLiofuF92pXitxybi3Yd4fG05R/Uw7f1/hhcXvR3G6bpui0UsHNbmuK0GoZe9sjKalxqampuL4sKvLk3QljtXixWn266kL7c/j36fk1NTUrIpuKPawteJJWS7y6CvxI6RrI0jdys6m+os6m4xexuMI9w9WuHmWNitGu5FaCi3eyMkm/j1MFlrM25N+DH4FmW5e9PdhMtnxXJei/NSTLljj2Y2/fUhwsMPj1r8kEf6i0xWXRzcu1SfCyYfy7emhlGXRyLvSdfig/iLxZrizcFoaGg8Kt5GIyeNuUfSvphY9mFY/ihXlxK0uYSlvotPStRz//xAAtEQABBAECAwYGAwAAAAAAAAACAAEDEgQREyIxMhAgISNRgRRBQlJhkXGh4f/aAAgBAwEBPwB07WXw6eDiT4ctbVdO1e9VDxFVaD1R80EM/VZOIyeXkD7/AOrKwtkqrZWwnhTuS1QuoQqNULL6Vnx+WJei0Wi0VVVRwEQkQj4Dpr7p7V8sfFQmVeJCxcVtNE+EWRinJbpbX+dOyq0QgSoSxTKMiH1ZA6h262q6N/tUuVJ8IOOJev8AfP8AaGMltknhJbK2VsrpUeVII1WhSJ+LpQsSdk7dx2sggL7vBT5QiNY/2sPIGMq/J+5bsyM6OHh5uoJCKPck+ayJpCKpeDfhZcn0rVQZckahnGbp59ufllGW3H7oHESEi9VKfTXlz/aeSo8XJOdisXaJkKhz5B6vFaqU9yQi9XWI+3MMlUZ7hWJZ0nFt90V//9k=";
const _imports_2 = "" + buildAssetsURL("blog-2.4961c893.jpg");
const _imports_3 = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wgARCABQAFADAREAAhEBAxEB/8QAGwAAAgMBAQEAAAAAAAAAAAAABgcEBQgDCQL/xAAbAQACAwEBAQAAAAAAAAAAAAADBAIFBgABB//aAAwDAQACEAMQAAAAzxq0bpr37rnIVQ2f10VPDxwTmvC8QDgHMwJ7lQlv1xMpKjK2RBnPR/zm4WS7nM3gIMNyR19C27tTnB8E+c3mr8hpFBZVTJuEFrMjAWgKk5F6ymvbmuvgWFT820uqs3o5g+D9zkVoTmCMYmMyAvKthvgmybn4HRPelvSpFlS/QPny3UdPYDGjRR9ovcXFazjN1eHtymi0mgpwNNDnFpAYMPxYeyCrEhOOBz0GnXX4QpLdbtLH8NZyAPTB5ix5kPN0Q474r3ZfSmehIJrdehUDdIDV/mEyqbkta4Y95oMjQnbwqnbzzpKA+u8dOVGSCLZpMxqJZvRQJ1MSg9a4CJtmsoMq4qbRhdaTX//EACYQAAEFAQACAgIBBQAAAAAAAAQBAgMFBgcAEQgSEyQUFRcjJSf/2gAIAQEAAQgADxLxzICI7LESFATTLT16C1wci0YccQhbGUlWo/LJT/BYkcyNfL2NH1EyqCMi/eNeU16S4w71cV/rWPj8gIHe9iRtY5a6Zvgb/dEK5GXAVMKfMdm+k15+Pfm0QJ4/+OS0j/0Ba+BM/ZexeMBJLi7VG3IaLvXRePREdH7zWpN+hlU8cxWUojG1FVN1DYzPfguAZurpnvf0vFT8vuA5G2EUj82crI/bDUReISIzOWgy3LP+kevFpLSyGLnDxspJVgxWTiEEUArB+f2sOPtCIC6Hc3JOTLsKe8ytx0LGHRXsL3jF6CKCYmR95NI/khjz620KmvXqzo32R3pkiSecrJC/rBKzDIjKwhnmPLGrtuM+XlFjaWk18gR+gNnBeU6osJphrUpZH/S5JjXjb1ZUXCLoZF/uA/xw05Ub0jpB5ALweBI8/OwIxZabPWt/bnR1PM9gPYnoUTgA7CyeH0gsvk/Odgk0+Um+Gl/LZEkwV2F0HJrK5pL/AExKt2M0qAiETleomUcLzGI/mHG9l0pS5U0XIy+ciCT4vo3OtMTJBABXVAtWytrArCgHICldGHYNkgGnXpeQh3mPOrvNZasZqDoZMnXRvPLSE2V59qNnazOUweWztXXhvSMkW2ilDqWRB5ZjEk/bWRGwp953pC9IZBIViev1RU+RnPmYDsuhCiqLeopqT8zfj9QLt+0vsESBiCLEtVMhFPNGspn4SYWrLaxtmY1JNEKKz9lbwOTWywQQTsRvpfnHVMlAxV9FqtqMUPNAP8R6auqMBPawmrCUHLEo0VHnHhxnbHoQctiotRfb4QYGZbPHXoelWNgw9FVxO/kLAr40/HL3DGB7qsoa4z//xAA0EAACAQMDAwIDBQgDAAAAAAABAgMABBESITEFQVETIjJhcQYUQoGRFSNygqGisbIkM1L/2gAIAQEACT8AvYyFcbMm++3INPEzeixzk9gT254rRo9JVOM5ycdqlddN1N/tmnBF19pJovLDFgRSYYFfd9DQ/wDHz70WwY5TjGfx+aGQLhh+jihsBJirm2Zw67CVS3PyNBt0kHGfwNXtxGmxGOwq7SJDeSBR8TOdjgKNzVteiU9X/aSTEJ6QjNu0RBwc6iSPlihh1571wEjPz5HFd0mH9wNbFbwjbxrWu+sfTNDAEiZI2IGocYp0lNrLKsbz51lBnY+TjzWkp6LOx8aAD2qZbW1mkIUgbRpnAAFXNzN1aIEw3AHtQ+QtXj3tjekKXcYIPgio2kAiTJGfI8UMFhKSp2IJI2/pWQ5vJDpx29tc63FdPmeK3AeRhpBAyOBnJPfApJLi5acnHxM+eea2MQYPj2nScg7/AOaiicQTsIzKjsuQfCb1YXbXFpdfdbi0tADI5ABIjLjAyDs2CRXSk6YLieI2UElz680el1OTJ5IyDUriO1tx6WDg+1yDnzxvQXWs0wO2BkYIOOPyo/vkujEoQBV06QeABmjgh3walaNk3VwgyG748Vq+/TPiM8LuQT+ZrnXIue/xtUMV7De26zSwIN4ZR7cEH8RAB2oQfsq4ujOLqKF/Vi07FG1HSpAGM5qadhbxtLbq8JEjhQSrMoHlfzr3y3Vgs79lLs+TjH14or6gmm1DuMgHejxe5/srGNbb9xSYGPcT8I+prPrzSRtAdgC2e+eOKSIajK+A5YnckjYYB3q2nup7GzW7aa2RmxGibsMb5yQuB3rp3ULvqU51P9ziyjgclySAuMb5oXz9AtbxXtOl9PQtNdoDp9fJ/wCxATqCge7FfadOnHqQIFtbOrpknfTC2GT+HgV9sOjekXdsGylByf5qthFLNOJLe5iJaC7jxjXGxH6qd1rlZGI/SraS715VYo+XPyHAx5NQuslqBKZn95gkxzldv5a69FD0OKd0N9uv3gD4hGuN2A8+2pr+06pYQy9Ql6vLc67mRbcDMQVQECsGyFqMQn7U9TtkvpLJDHFNFckYuYl/CG1YkWoxDY9OhWCCNdgqRgImPoBUKJdQ65oJwgDLKuSpBxSBZbtFmZRwCQM0gN/EhuLGXG8c6gkYPhvhPyNIySwyHWNjhio9v1FWbWloCUD4wNAHHPbnHen0ffJUtkdMg+5sa/m2N6gWKw6YqRRAbYXgsc9yTknzQ1JEJLTfuCpJH+KC6rMxqMgH2BdxvxxXC6VH9SaZsuukpn25GdwPND3RQqpHgn5VyNxUDjp3VHHVbLwEmJ1r/LIHq1u5zcZZprt/SAPGsIuSfIDc96y3Tehxm9dyOZWJWIf7NQ9rAgg/Oj757lyc8743r4EulaM/JlIx+tN73OAo3yauUg7ZcgH8hU2vXbxTk74OdQ2z/DRGrx3qEi5huZ7F38o6CQf1SjgwoPg3UjONqmQ3fXLw3L5f4EUaUTNXnoagQJExkZ2GAe9TO4lhAF1K+FaUELpKjg4waeL0LRx/yY/cZXXkgnbSOM96m1kAyp6kzITggkAqQd/hwDXSblZRGMyyjJjXJA1E7jYcc1ATetGIjdlffoBzpHgZ3xikiuLf8LAAMPyOxH0qcw2Nrem6lSMDXIAhAQZ2Xmv/xAA0EQABAwIDBgMHAwUAAAAAAAACAAEDBBIFESITITEyQVEjYZEQFDNCcqGxBlJxNIGS0fD/2gAIAQIBAT8AxCS6PlVDg8FZBHKWWb92WI4B7iRSjlbw9VJhwjyyO25SnbzLaDIPmnkG1Rn4JDd55Zcf79ELqM/EFV11qwOS2kj+p1+oZLqYvqZVMgiIkXZTugcUDXCSHSJIED+IKna4dXDNvyqKnhhGSLoJv+VXwR1UMkRFwbP0WL4lcRT2/wAN5KXE5pLuyoK33gezsoLtVo55qqjKHSW58vTjuUD6U3xBWxqaiMthCX2WDVG0gIpC33cXWJ1GzhkVfDtOVbMYZrSLc6GcaWe6Le29YeG2j1dliddNNU7cuYcm/wAerqStmrCuly3dmZvwgfxBTWiVxE7bundYcZFDJ9SxX+nk/hYrDdCJCX/dlLSkQjpWzukEVRGUfKqpvEJUzaSUfxBUhlasDnhGOQZRd3fhll6b1WnNIJRe7ZM/cv8ASqAK3UO5VcNum7cqaj2Nsso8PVU1dCPKW5+z5OpXGSQiHdmmujQP4go5NKgrZKfUPFVGK1cxapH/AAqipmkERLgPBDEJSXnxWWpPGJIX+65tKCMrRJBh0w2lPpHzUEIkJEXBlf8AMv3LLlXzK3Vd7XdPNDd1L7N6b39VLJbGQ/u9kb6Vcr08wjzEttGUmks0LoHuFRwFzEqsx2to9E7XChaMVW1ZXWwdOqjOci5nQwFJJaoaeOEdKFbbZr//xAAuEQABAwIEAwYHAQAAAAAAAAACAAEDBBIRISIyE1FhBRQjMUFxEDOBkaGx0VL/2gAIAQMBAT8ApIuGW5VFQUZEPJUlWMwjzwUb3fdPuVqbcrNVykRt4ahcblVtdIXsuzR2+yj03Xc02ok7JtyHcpU7eGonwJTVUxW+WYqnlKEYy5qipOMdtyj7Hij91X0XdS5s6bco7S2qdtSf5aKyMriJlXRkMrcMfRUsJSRxrs+UYdyecpobhHNPEVZBwpcnyV/BnK3mqaAREh9Hd3+67vHDpi/bv+07eGpGItNrKRhGUfZUm0V2UYjNqFQSjcWpvNEVkZEha6RR7lUbhT/LQhcu0IJLwtVK1o/M/CpruJpVDXEI2558kcvfCKmikYcWfN/L2x68/JlL2ZV0xEUsRNh9v4hO3cKktktTt4fwlgEhtJQUYgPRUMEEYl63YM6qBEYboNuOD9EJ+GRc1HWSCXnk+Tt0RwlqD/OSdrU8g7UDiRaVI9xDEPqrBYuGK2kPXNHM/jdVhotWPkna4SLm6Jk7LErdIs35f+Kma6W7kmcrlUBhL9EMVzfRcArU1KRbRxQwH3e0xzZ0QEpWtUs4qlj8K7mo3KMrrcVJJUTXW8/LoqGG0b5fX0UvDtRmUcd12SKplIunJHq1Dk6OO7cv/9k=";
const _imports_4 = "" + buildAssetsURL("blog-3.83ad3c97.jpg");
const _imports_5 = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwQDAwQEBAQFBQQFBwsHBwYGBw4KCggLEA4RERAOEA8SFBoWEhMYEw8QFh8XGBsbHR0dERYgIh8cIhocHRz/2wBDAQUFBQcGBw0HBw0cEhASHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBz/wgARCABQAFADAREAAhEBAxEB/8QAHQAAAQQDAQEAAAAAAAAAAAAABQQGBwgAAgMBCf/EABoBAAMBAQEBAAAAAAAAAAAAAAIDBAAFAQb/2gAMAwEAAhADEAAAAK2y17gasWYJcCUiaskpiNq162D3KPR0jmgoAueIS1LV6EBJLHNPU6+ffoXgxqcE83ot6BFkMjIqjGuIYQl0UdPd5gc0PQIIfIoHZWlUiYuXo1LYiKkMFOU6ZKGk9ReWiVD1t6F1+XRIPoVqt5sGeiWW5WowTFompsHPZdNbQwOYHntJ7OazqZJD5HYMT0bbNW2S99kJzm9iKBpig4WmQrFM8asAhjE6vKbN/P8ApGDlMvRYz4aQ5b+5XTkLmdUqh1UfuPitB25a8w0gGEzhCuns/PZYBTr8v9NX/wCt+U924h7c8am24GyvV+9R2LbbO3kdn//EACgQAAEEAQMEAgMAAwAAAAAAAAMBAgQFBgcSEwAIERQWIRUjMSIlM//aAAgBAQABDACZWV8ce4Vkwz4scRY/JzNTr1WNZ5SW1XfHQSlARstqLZ416EB8kZXO6h00mYNER7EG7AyqNxiSReX4i/f9GG546MRTsaaYMSTUC+W+JDNzM+Hw0RHEmEYthWV0GSwf5J/A6jruPlFaH8RbONAIgPfarLvLysq2AG8BnGtJUhWfuKi1mU2tWxw0mHcGBc++VjWTi7q6MLw5WTnKbjrSr+7Y0o8pEURUnMHuZJr54WKBWeJiQTj2K8rUfQQNiOGXa+JhFnfGY+MB3HJ7W81gw0M4YHHucUtsZkvDdVUuN1EmpCENwy+CnuziRjgS/Aw3MN7Hc3L5MWOCO4b47TSYESvj14UE+IhI8ese8I5RY2zSLAMd1FubmufLjMFiGmlXVjr5JRMRSEinRCCewqfg6e8GUFjXxpYu5nQfFscHSWtFFZBWThdH43MDGY0uBVs1fAHi6P8ACJhQf6mIx1sHGZ9p6QIAIQiQsWgxxrKgQl67d77GcbzEqeigpVrUAm0hoxQAMPAKfLcezG0Wuqkqao2umK0hXjmhtHv7r9YK3NX49T0R/ZgVEinKNzbAD+T1KyRGcSKvB1OwPgd5Dbu2ScSkNXy2WhuhVbxSU59y9drmLHvtRR3BQ+a+6t2Vdc5yC5iY5lMCYIY5NhCSwn4BhkL8jqVKXijW0f51d2NojGQjyquZHK4SiL5qautBTRi2n/ayjyZo/LgkcGlKGKPjc8vLmz4MVSmKpHH0Bwyuw/STFD1/31ko4rxokoADmmJPoa+fk89BQDZznt7qJArx0KHZiWL012f2VlU8vyPFLKAc1jYhcnWU4fa3YGFiwOfoef1lT7fNMGRLTUObIeX0BtisNLPKe40kzzG7Qr2TZaHQItqiILOM/wAVroE988E09f3I5TjsHtyjfD9noU+UXWLkeSpsDxUrdc7lkcAZQ9yxMzsb6KWVXAdIjPyuUImxRFATj+vKfwg/rpE3J126wFv9CWVk8yfh8pxCJNdOuJpyyoerGFfGtGGSfeKtaRE2ORP6Me1PHUGZNqSpJgSzxTzc9gQKqkJPgsmzmf5fXTh/XTE2/XXa3JLM0htIn9ZjuUOoX31bkh0lG1eyUNtoVpXEAVVQi7VYnQU3J5Xoj/tETqivWpDChwsOv//EADgQAAIBAwMBBAYGCwAAAAAAAAECEQADIQQSMUEFEyJRYXFygZGxEDJCYqHRBhQgIzNSc4KSosP/2gAIAQEADT8ABICIDQMMsZqMKF6Cr4kqRkUjhY2xz1qclyTU/Vg0PsAHFLAaEmhMM6bMzU58AFEwWKGceUURMlIwaVCFdwMHpV55cgGccV0UMQAfRFSC9q544HmCeKuAzAWPVigJKvtI+VL1SARQc7VnO3045oGeRifdTCPr4+VcGTI+VM+ywOO8zEiiCwsUDzcQjwwBEkRilEzHPQifVQH8Pr8aJ5D9epq7M3HO2PVRyzd8Mz6KAJe4boz8DVnRTYa25JS4xhWInOa0UIBHhOzE/EV0ZGBn3irg2st+0rCK1vaS2L9tCdhQozVGPHn51bHi7tx+dMm5rEEmDxmaDT3qckDpkxR8K4yfXBrtfutLp+4AI3i5NXUI7q+CbZPMMBmKQtcvdnWr76jRX03Eb7RcTZeIbaCVM0k7zpNDcvC3HJO0YFWbf6/du/ffCJ7hXRw5j4VgSOYocb+a9AM1b+y8gfjXYtq5eLgSvekbUH+xNR4LQIBc9BJrZuu6dLoBQmcAHJGImhbOv71JS8hwdgIMkMQBtMzMVrLr3mQiFycADoAMUDiEOaKDNwwAPZ862YNoz+FRyEEiryQiHk+mu1tBa1Wpvfz3bkuSf8to9gVaBbT9758SG+yw8xXZtrvX1GotJqz3AbMOkOMEgT1PFaXNlAJfUXAID3AMCOiVuOy44CqQfKhB3RhBxkCgnhEYzRP7uzpAWPvbj8aucufG5+OBR5ZzJrsw3bVq7c4fTSWBPsywrTONikIovCYO1nIz5DmOYr9J9VZtC6mGKId9xXByDKAEVc+uiGUfylTSP47lswCPZptoYI6mIzmggaDEYEH9i7euLdSSN6rdJYN9yuxbtx00Tkp3mhU7ZkztuW5BIjKkGr/b5v8AZ1o3u979bqEtcn1JRxQo4D2nKn3xzV60kkGTuKCWIofTY7bWx/Zc2M1drvqbxa4ZS2t3fiepdXIMYC8ZiFu30I/oAJ/0rk/QJ/KrA2cSwE4r/8QAKxEAAgEDAwMDAgcAAAAAAAAAAgMAARIiBBEyExQhMUJSECMFIDNDUWKR/9oACAECAQE/AAYwuQw6ldN/6zuiG7H0idV1CthvEYOuHjbB1c62PGBxuKd4z4xTWEPGdwzjbDSTMrYnSiLLpYPxh6VJchjEdP2+IypfGbsHjK6QhLGVBi+UDqDO4OXiI5TvhEuMW5bOJStpDbBQPuGVSXtmV0M2EzLeGbOQ7wau93ib3Q7YmglBYS7st/EDVOndMEZXuR90XV4jddvBPUsLEqwTZda3zNrRjX3cfM0xiyaZeREUZR3tl7BLLzB113IYOtH4yrhtxh2xjLRi645QKES8SxrL+iP8wWCUaxpMLpRZiMfS4rh9JoRYWI+k1QZXRmOUG4itEd6wDWn7TfWPejiJUncLIbRiNWlfunYOZbaP+xegWI5eYACI2jDpC0NxcolIrxGP0qXfqjvGfgy/2ihpFJWt8Vlk2lafSvKXzfL6bRiVsG0h3g6AmMZ0vFN4M2+leU6eM2y/JqNP9y4fG8//xAAvEQACAQIEBAQEBwAAAAAAAAACAwABEgQRIjITFCFCBRAxUiAjM2JBQ1FxkaHw/9oACAEDAQE/ADWsdpQKCQzL7pyol3RuF4Y3QEEUrgvulcJODq3Q91ozlB90NKxLdOXXuugOFem6NxREu0cpUy90DEMHaUS/iFbd1gAPumSyg4oe6Ca2bYdFkM5VfbOCRFpg+GkQ7qRmHYvcMGtpXQ8QXaUFw90zER29YuixHTlBFfdlBokrrev7TK3bAujTYMYkWCOnKucLCp9s5RZFMkF20jBQRW25Sq0COoaSxY/S6ZwT1ROHt3dP9/UxSyXMWwbREYmqS+qMsWQ6ekrgPaUrgS90FJCWqBdEruKNDVpjTES1Dqp+MqvmCu9Ia2DFgsVjxYwLonSNsx1Vr1F61mErptiK6pinJtu2w7nfNV6RC3dwzhEJXFH4djO2Vx6V7i/iM8RYRfK6QzJhXFA0jdFYplu3OPcTNRRGIcn6RZRfjBfmjBZxhuV1mZTODXySNwxaSFlwlll6RtO79fNbCWVwllK40VrXxetaysz8kV0yr7tIxldI/BhcR8kRLrlP/9k=";
const _sfc_main$3 = {
  name: "Blog"
};
function _sfc_ssrRender$2(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_router_link = resolveComponent("router-link");
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "news-section pt-100 pb-70" }, _attrs))}><div class="container"><div class="section-title section-title-lg"><small>News &amp; Blog</small><h2>Company News &amp; Updates</h2></div><div class="row"><div class="col-md-6 col-lg-4 pb-30"><div class="blog-card"><div class="blog-card-image">`);
  _push(ssrRenderComponent(_component_router_link, { to: "/single-blog" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<img${ssrRenderAttr("src", _imports_0$1)} alt="blog"${_scopeId}>`);
      } else {
        return [
          createVNode("img", {
            src: _imports_0$1,
            alt: "blog"
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><div class="blog-card-text"><div class="blog-category">Technology</div><h3>`);
  _push(ssrRenderComponent(_component_router_link, { to: "/single-blog" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Is Machine Learning Right Going On Good Way `);
      } else {
        return [
          createTextVNode(" Is Machine Learning Right Going On Good Way ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</h3><div class="blog-card-entry"><div class="blog-entry-thumb"><img${ssrRenderAttr("src", _imports_1$1)} alt="author"></div><div class="blog-entry-text"><h4>By: <strong>David Joe</strong></h4><p>5 January 2021</p></div></div></div></div></div><div class="col-md-6 col-lg-4 pb-30"><div class="blog-card"><div class="blog-card-image">`);
  _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<img${ssrRenderAttr("src", _imports_2)} alt="blog"${_scopeId}>`);
      } else {
        return [
          createVNode("img", {
            src: _imports_2,
            alt: "blog"
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><div class="blog-card-text"><div class="blog-category">Robot</div><h3>`);
  _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` The Current State Of Artificial Intelligence Infographic `);
      } else {
        return [
          createTextVNode(" The Current State Of Artificial Intelligence Infographic ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</h3><div class="blog-card-entry"><div class="blog-entry-thumb"><img${ssrRenderAttr("src", _imports_3)} alt="author"></div><div class="blog-entry-text"><h4>By: <strong>Lona Rabisa</strong></h4><p>4 January 2021</p></div></div></div></div></div><div class="col-md-6 col-lg-4 offset-md-3 offset-lg-0 pb-30"><div class="blog-card"><div class="blog-card-image">`);
  _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<img${ssrRenderAttr("src", _imports_4)} alt="blog"${_scopeId}>`);
      } else {
        return [
          createVNode("img", {
            src: _imports_4,
            alt: "blog"
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><div class="blog-card-text"><div class="blog-category">Machine</div><h3>`);
  _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Our Company As A Global Leader In Big Data `);
      } else {
        return [
          createTextVNode(" Our Company As A Global Leader In Big Data ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</h3><div class="blog-card-entry"><div class="blog-entry-thumb"><img${ssrRenderAttr("src", _imports_5)} alt="author"></div><div class="blog-entry-text"><h4>By: <strong>Richard Jac</strong></h4><p>3 January 2022</p></div></div></div></div></div></div></div></div>`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Blog.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_8 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender$2]]);
const _sfc_main$2 = {
  name: "Newsletter"
};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "newsletter-section pt-min-100 pb-100 page-bg page-bg-2 page-bg-overlay" }, _attrs))}><div class="container position-relative"><div class="section-title section-title-white"><h2>Subscribe For Newsletter</h2><p>Subscribe To Our Newsletter &amp; Stay Updated</p></div><form class="newsletter-form"><div class="form-group m-0 newsletter-form"><input type="text" name="EMAIL" id="emails" class="form-control" placeholder="Enter Address*"><button class="btn main-btn" type="submit">Subscribe</button></div></form></div></div>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Newsletter.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_9 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender$1]]);
const _imports_0 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAf4AAAG/CAMAAACOtUXeAAAAn1BMVEUAAADk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/jk7/hCZTLbAAAANHRSTlMA+/jwDeoDAtXfziUVCcl99IQ+BmA1Eb6gm4tsUOXaZbm0RKWXWitKHHggxLCScqo5GVQxStoh1AAADjdJREFUeNrs3NuWmjAUBuANIiAeEEVE0FFxPCsok/d/tna1XV1trTOKHJLwf3dexyT7FAieoukEktM7m8t2Pd8H50myHFtW67tGo6Gy377/arUsa7FI/LMTz9Po0tYIBKa1B2no+MvjW4Nlos6sxeocrwftLoEghofItSdLs8Fy1DSX53i6wYHAL2+0tv1xS2EFavb8/bQ9JOCH3p7u/WOTlUZ5Ozlp2yColtFOncRUWSX6vUl4QVRQDW0QTnp9VjXFep9vkDuWyYv2yRvjSH/sbBEVlmA4ClctxiPFOqcdgsLspsFRZVwzA5wCBRhe4oTPTX9DPdoj5AR5Lr095nzT/6vppzgEcqCP9ovqo/ss1HF8IMjO+IiXDSYya98myOIwPzWZBCx7Q/CU7vZsMnlY8ZXgQYdwIVic9zVl4SIS/Jo+CGTa9n/q+wOCT3SnvhS3/V1mjKLgHdo6ETO/e4qaRCgI3fDWJ+mu+3vMOaKAP3Xmy9qs/Q+NAOWgXzrhWGG1o5wuBJq7qOHa/zTe1jsIGE6Tep35/7LWtR0RMi4TsYv5uWi5tfwDHGyuBrUq9Lau2xWguWMGv5m1+gN8vOPQ/4e5pXrQ5haDW4sPkt9oUoOqbjaKvyOpaSE2/mdUR+LHQhcfG/8rrSlJqYsb/zELCecCD4HcPXzcAPcZ0am2Rf1M3iSaCBq6sg5uFehdkmmAjj1j8LyZDCHgZlLvdt4rVh6J7XJikN0sIoFF6Om86izqp6OMtMfgZZaQL8MQ7Oel75JouqEgH2AQwkqsFNCzUd/LlSlQEdhzMMeRt35KYsDiF8MRYRIMi1+YJfcBgGdj8Ytj8v0grLtHwFeoJsfvwYYh+jpFU3kNAA0XeX4ZYuLRFhW+kgT8JQAfaOyUx+fsMeBugimuMp14agFqDoY5SrbgZgpUR7hfgTEnBSBEfNU48rD+iPgqM678/L/6iPiqsxxSlYY2nupVKtGpOlN8kqVqvkEV2SwYVC6gSngBMn0uhFQ+w0VXlxPKlMp2weg+P/ojKtXVZ8CRZpvKo8cY5eKM2aWyDFDh5U9iUCmuKwYc2lMJ9BhFPj4pW7qFc782GgcqVgfxPs+OOhXImCPe55tDxdkcGfBNiagg3QBNff7NOlSILd5uCOFEBbgmDMTgUt6MECGfMBo7ytcGrT2RLClPQwchn1jWlJ8LqnyiaXqUE+2MrS+ed8pHhGxPRMqIcuChwC+onkEvm2KQU1guvcjDTIfAZhq9ZIvX2kKz6QUabn3BNTqUWYStL7wzZaS9MxCeeqBMRnixK4UJZaDbKPPJIcv2P2CeSxoTetYafX15qFd6ioZKj1QCesYI/R25NDR6XIgPdcgmpkdpmOWUT8ugx3wg2ZfRlh4yx8EvpSU9oIuIX1JKm760sxhIyqGvDDDUI6+ZQZ+bo8Yvs4g+M0RzV24r+oSGz/BLrq/RXTu84JFeSvdsMNMlvxPdEaG7WwOqRv+1RqWvFlL6HxcJXz2skO7XWVOnGyGDuhjQv2IGtRHcnPwM6qNHf0tx79eJ4tGfRvgge72k9Ic2Grzf2LsT7MRhIAigBeOxJwHCQGwnLHlgm33CrvufbbI+shBW20jq+lcIsaRSd0uYHjYqLO6Q5hob7NwXpxBy0y/ZEG8GDPoFquGVy+m8EnWZ9Ur2Gy/KvOGXaYRnTUUitfEkZNwnVJX3fJIleMK6XqmuAZQUCVV0GfhJNgHYzyVXDHQVSdUBOLFRribAdk655gBnd8l1A4wVSXUFBIqkKnpM/SQrA74iqQas9ZGsDmDAG1+p2njSVyRTh629ko051kGyKl4N2eInURNvlrz5E6iHd96MrT7i3GNj8qhIlgQf1ZkAyZLgE2/IH4AkEb6KI0VSRPiuNGXTnxARtnF8VgCKEOEHpRofb7VfhB959R6jQMsl2MWNp3zbwWYJ9vCCGl9ytdY9DlCadRkIW6mHwzirBpcB+zRxMG8wvuNHwC5VHKUynLIu3CIzHG3p33MdsISPk5RajwyGLTDEqdygyq2A6QKcoxI3r1kkarASzlVeNZgLmcpBGiadOa8HDFREWrz1rMtmMcM8IE239RrfhDHJNdK29LkOGKOLDLiL2g3PAyZoICPlfsKPgPaqyI4XVPkR0JuPbC07EZNBfdWROad9z2VAUyPkwY1ZNKqjooecuPUeb4l18wc58upTfgO08oh8ucOEwbA+msid0+/yNKgJH5ewnLFeUAsBLiTosVbs8hxcTMXnIIkLu8JFrRvcBx7L5I3/N+GYYcCRDLnwOZC74iCJS2lDB0HCk+DBzEv895tMuQnI329oo1zjQTBvETQS8gewl3U7v4/CGpeAPMXQzHLK0qD8hNBOiVOldzL1sv9gC2bB+ehBS57PJDAPfWgqbDIH2s7G0GeLNVeArey57tvNa/EQ+I2Epf/dhFdBmVpBb+6YO4DsFDQ89X+xZklgZv5Bf5WpomzUYIKYjSGfmNTcmYYRj4BZ+OXCDLc9Ra9sqvI8XIsngNS1YI6YhSApKyxhkAEvgdJ1A6OMmACkagyzhIyAn+kzyTlnzp0iuwt9dqrw729rjS///vlaw0AOA0ABlR4/C7n/N3WkTypGPP+L/fY/G7AETOS+/12b+b+4zOejqqLzFDSu8N7LYxfYme5gMoevxpk4yzE1AZf/c/x1YDYu/+dIYDiXt39nGMJ0Aw6BONmDKTWe/PxvSKvv3+2W4f+JChNYIFakz7Od+YsUmTvH9WwlHv6lbvxesPdHSpXXViMe/o5XNKq7g//+KZvDGhOu/kdbwB5zRVa3du22UPSfvbtNSiMKwih8AUGgBIlGxXwgiaUpTUxi0vtfW6xKjJTAMKP8oc95tjAFM/d299vIU98/w1ATs/2SyUUo60x/DXuO/TfRHZVcpiFWrc/Cz0u1D0oy+w791Hde0jH1sbbWdUnnKMS77/2vZ+Zn+rHOKueh3VvZuDUfQrWclIz2LPuRWvyWmPeDq/QuuglR3/xWfdFv/gc9yz6p0ttt+N+6Vsozvy9/yki3976v0Nq5/OYGRvb77/a6zlcy6bXaJM9oh+MeNvk88zZUobvrSU4bXIcqXJTcen77Vehnmej224+Z42XLh4XeCu9DoP5O7/1quyv5HYRW654WAGu+jJnONYz4XW2Y/tDnpz+wwe+Z76EVpoXhS2hZJ3el78ltiPrd96DnrMeyca4gnyqDEKi901GftGt6PfltwyB5k4fN3vA674KrEKazf9lJaFE3XYiXNT/OmtbGbPdDjHOv41bnBZ1dXtDuwd/WbsN9/etv4E0I+9dvsy/4q994P0iOi/c+XvjY8MFZ1lTXKJQ0s99W/9pmpDKv137PtNKmNzrpUcNNoXKha8QZY6jHpT4rdYHXfY8OA4955nOfK2eUf61fATc8LmD0fZ6TzLm9hvttclXQ7gMtd2rzZsdBxn7x0y/9O7eFjnzpTz7xm+yaPLG9lnlQzblX/U8uA2qAbO9yp8dfbWyN305/aF+32X4Weiz5RZzh73vIJT8/+8glvwkovG2D38HjbR95zuew6NFp0FxyUls32w+Y8agIW/Gd+dEPjnXuADa0NTIMkPbnIm64F7yzEz7lx53lNNSds6OpiXdBYZ2HPOTZp0Z4GO334CN4jtuVDh74ybscJ5DFrI39DIA2akePM75e9zjjy9vLarCn01zu83GIv7Zu5PbDWT7wiPfcq17wiPeZvV3gEe+vXvSDC/5jnz54xHvo0wePeA/t6gUv8e/79MEj3rP7Iuwuv5ntHbUcRUYDIxvBFd+Bv/2aDiIf//lr60U6fvWRS359nz645OdtD7nkNz4tauBTZGKNr6FpJDK3vg8e8vxmbw+45jO1rw9c87kzs+1Pe3e4lDgMRQG4aSy0ZQREWClIFUGUKbAsnvd/tt3ZHzvqygilTZPc870CMzT33pMbwTMf7msUPPNRvMtTSgc+CHmPT/DMR3NlW0ltBedFfJqntBlcl8h+iFt407/LIc8FNnDbnG1+wRc9Mrb6BK/2Y7NHcNeX5b7k3W7RIKALjeCqnAWf4LZfwVxXFfpw0pjZjkrEcJDi4wyC97v0+RZnIPdFjxnf4RXc9ynY5Q/k7vTPeOiTG/dirKtar3BJxGBPtdourXVOubfjD6mF/5i3uP4SGfjgZ/8jWdf8ZhzwvSNt4l9wbcc/8iq/CVNd7wgb+epDQB8JWu8UM9nxmaCZX8Z67zM5R3/NQGethrBZyj/+rwhJe24536vZtb23fCPGeo4R0PUvuJ35KO/f81Js9Rixg4042jdkDwvNmegz5Na+xEf/ISBTClimy2L/Gx73/VSPZz6TDrBJzk1dp/A07ZtxW49pCWwRvQR0Eh8v+m1Y7p3Mu5tenO024xdsMGeasyEpGqeHATXkBk2bc7p3Ln/S3hG/+k1qRWjSggf+s3lT+s2Y6SnHh+2easkNfY271WhGzJubNsjQhLDHJK8VBmjAHef6lmgnMC0a8uVNa/Rglsp45LPIq4JJ6T4gm2xgjp4yz2WZAUxRGbt89klhRpdhPhsNYcKM5307tRLUTk2Y5LTVEHV7XAVkq1aOWiUc7VntHjXSa65ostwd6hJuWexZb6VQjw2HOy64QR26HOq74TpH5ZJnVvquGIWolt4x0eGQNaoUTjjWdUp7jsqES17ecM1VjGqoMV9eclAnQgXUgrWem1a6gh+f3X1n7TUu0t/yb99lbzOUF/V42ndcJ0dJ8ZSTHff92KCEcMH2rh/a0xBnytec6vmjc4cz6PETW/t+eYlxmv7PA7/4/mk9p/hWkt3zt/fVYBnhuPBxx+ae326fJqnCf1S82I04zBXhavQwWRR5EmmdxMVmuz68yf3D/w246eLAJId5kAAAAABJRU5ErkJggg==";
const _imports_1 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFQAAABUCAMAAAArteDzAAAC8VBMVEUAAAAyucA4UZw7T5w5N5M1n7c0yMU6P5c/l7g+usQ5MpI1u8E2ZaM4NpQ4Rpk4Rpk4OZQ5L5E4tcA5NJIyy8U0mLQ4NJM0ysY3pbo1i7Avy8Q5OZQ4OJI4k7M6TJ04Tpo8dqo4UJs4NJI0zMc3W58v0sc3faw1fqsw0scu0MQ6tsI3X6I2b6U2yMY9rr85MpE6ZqQ3QJc0ZKJDxsgvz8Ue2cQvy8Q0dakyrbov0ccwxcIxmrQ2WJ84MpI3R5k4RpgzdKc0jK80tL4xycQ0u8IyoLY4QZcxy8U4Spo1sr83usI5QJczqboxxsM3bac1YqI5OJM3WZ81jrEt1cg1g642l7UypLg4dqo5P5c2YKE5TZw1aKM8zcs4VJ02ha85TZw5M5I4OZY5U542o7pSws46TZw1YKFExcc4L48yoLU4jrMyi68xi64i2MQ2a6YvzsY0k7I0bKQxnbU0krMzpLgyprg4VJ05TJs4TJo1dqg1dag4ycZBp747o7oxqrk9u8QxwcEzjbAymbQ2X6E0eKk2XKA3Up02YaI1cqczkrI3UJw0gaw4RZg1aKQ1ZqM2Wp80hq41bKU3Tpsym7U0g600e6oynrYziq83VJ0xuL4ynbU1dag1b6Y4Q5czkLE2Y6I0f6szlrMwwsIxsLw3S5o4P5YxtL0zl7M1bqYwu78xqrozlLI4PJUyo7c1dKg1cacyp7kyorczkbE0eqo1d6kxrbszi682ZKM3RpkwxsMxr7s0ha02WZ8ypbg0fKs1aqQ3Vp44OpQ5NZMxsrw2V543TZswvMAyprg1a6U4N5Qxqbkwv8E0fqs2XqA0gqw3Spoxtr0yoLY3SJk0iK4xrLo4QJcwxMI4PZY3WJ4wvsAzj7AyiK4wycQxub8ypLgvy8U3SZkvzsYxs70yqrovysQwwcE5MpIwyMMyobYvzcUwub8wur4v0MYwrboxrLs0gq0rwsAr0sYttLwyprkyo7gsz8YuxsIwhawn1cUszMUxfKmFkDmWAAAAgXRSTlMA6gMOdCYkFgsFug718N/Z2ceopqGXlHtgYFlMNDMwHRIJ9+jY1ru4o46DbGNTRD0zKiYcFf76+Pf19PPr5eLi3tzb2djR0M7OxsTDwLm0tLSvrqqqqaenoqCfm5mRgnFtY19WU01CLyMdF/f28vLv7Ovp4+Lbz8K/i4qIhoB/XEBPIC9jAAAJbElEQVRYw6WZZVhUURCGj93d3d3d3d3d3d0ttqyo2NiBhYCKjYK9q9gNrojYLXb8cubU3Lu7Kur97/vMzHu+OWeF/elLFLfotIIpG9aOAV/NBikLpi8aJxH7ny9m3CLpmlT8sjkqKips58tXXlevfji9JbB846m94iT4R2SpjKlr3fvy5cvmJxfCrOHhgNwGyMC3Pj4he8a0TT/gH5D9JtUre+/ZkdubN18IC9u508vr6jZkHjgASJstyO95nTRZ/hIZN3Wuz98V07pz50vFfOPjs8cWdN/v+YoVq0e2+Rts6QLDXkQ85kzoHZjhwHyIzJtQ554gP7+9wFy6dEalNAOjiUyQMU9k5IsIYB5BZhjW6YV1bjnwFqE2YF5bjcztm7aPyhA/Wp3nfx0ZGfH4mWRarchER1DoI2AGfQImr3PGpl3z589vGY0ZFMnzORJ7P3Lk9m0xz1c0T3R0fy/OE5DbgRmwfv3dGhn+xExX4TVnkqNwZIp5PgJHwOR1KqbbQbdBXX8/zs7vsXdyZDV5D4E6cZ6yzl0B6++6ua202+2tY/0mkvm/aeZt4ShcO/IJgXneV96ROR+ZB1feWHz0a77sv2LGb/X6tZwnFHoBmkemqNMHmbxOnCcUCooCFHPZu695f0FN0Op9JDKfIVI7uvrwdGBg4E1gynmSo7uAXGkH5mXLRkveHC6hnaH3iIgIOU+Vo4fkyM/vuZgnMe1Q52WLZWPw8uB2Lr2XIe/yzBu9f8QcqTo3oXd0JOu8GLx81r4JzszeQ94rJp15rHMLMME7OnouHUGhwIRCiblv1v5yhZ32XJ5v6F1n00re4Sxh3rUjZJIjgArmmjXVSzqIzw91vqAcWcGRFzjawh3BPKHM5+QoYD06ugFIrHP58lmz1qzxn7e7aSxz82Wgd+kImZSjN4+ACb1r7/NxntIRZ0KZUCcw1+4wDaB0rvcy78QkR5ypz7xwBHWSI8X0HJrNAC3wOcLoiOZ5E/cSOqLzKXO02Jm5w9Ojk8FShUiRI0DKbPL7CJiPiAlQzqQcCe+SudbT87hH4uIamvqz3nWyTnnH4Z638f0JSDFQnCedpeWSOQ969zznsXBhM33H5frOmZRNuuOgTof9iWXeWLxMOtqn53nuuMfCQxsS91UTNTLD6T4SdxyUSUxQ5CbybpF1riGmx6ENG+Z2kOrrAVPdcS8lc4tg2tQdJx25qXlaHBxhnQuBOTO3SEDGspJpdgS9f7SZvQcI7+RIMdERNA/MmTML8Y2XGs8S7U9R51s4n/qOE4qwefIeDMz90hE0D0jBvNQCd2DcWuTIC3sH7QdkNp33p5070vOcN2/3buUImJdmz55dOSten3THiXkKJuVohiFHdOZ1NskRMhctWtQT9ygw4czzHULvELHrzDvZDc/SYkOO5vEzrx3NROaxM11iskRN+J4Ps4J3L8XEbPqZHYm8H1WOZpEjYApHWGjomTO547G4FUWd5AjrxDNPTO2IckTMc8ici0xe54lVq7Ky6befXIA6pSORd5hnECCVd+HooB1ah/NpwXnum+VvyBEyscxjocCcM6cPy/hEecc6Dxh2nZpngPB+Q9aJx9MhR5K5KPQEMN3du7GCUZijV+Zs8hwtJUfO3uch08kR1um+pCNLGQV1kiPs/VfvEGge5qkcoXdyhMxQwVwyjjWM+oUjLJSyaYd5GrLpz3cy9i6YVKf7krP1WW0rxv0q5ihQvRloLylH2DqfJxQKvUPzqnftCOpE5BJv72QsxktxH8H6fCOYeL2b7jiYp9p1DvOkHIF3wTzrfSUpiyEdUd5Fndu1o4M3jEzMO/Z+XNSpHa2C3gXzQVWAwqoTZylEOlrt4o6zOOZdMy85Mq9XYzG8kLlF/e6QOZKOaIc47k+T91DpCJlXrh9Oymrydwjuz5CPNsiRq2wS0x+9YzaJCZKI6Q3MBclYgw98f94MIe/GHK2k/akceapdR46od2Cuq8tSfuBnHpmfzI7ceO+CGcyZ/tq7B52lM47MdY3Y5A+UTXKkWreT9/2mu1hnM5QcQeuHFyxYd6s9S/+B78+P3BF5D3B+29A7hHbdMShUz/OBYN6KzYoGvn2E9yZkc4Xwrt6KmhkcvA8dQfNY5zlX3t2xzusLgLlu69ZMLE75N9wRXnFinnTHYTYvb9xIZ556N2cT6xTzvLX1jm9mlqjxG5kj3js5EjmS+9M0T8r7CfM8kbn1TvJ4jE0JAabsnZgH7dS7Ie8e6H2DUzZxntg7Mn3TxmSsl42/68gR9o5nHten4x0nmLQ/KUea6duDMRZndBB4F3t+FzJRO+5Pl2/FQ8o7ns85OkfoHRzdAWaSzPjsaesH2QSk+XwCEpkG78dpf0LzcJSUowcP1Dx9fU+ebM5/+qWXP4+gTukdHSGTx30/tA7ZJEcy7so7aDcyz8dm+A2oY3YErRtzRI5of+K9qb1LR9A7MpOXYPxLY2CCI+jdeX8eVzki75R37ejk+fOpmPiyVFLesU6dI9M7xMg8Ztx1wFSOTgIzZyYmvzYzNvG84/nEHMkzr97ensBUjtC7eDNQ7yJHWOepUwmZ+uLw3u+iI3zbSEdy15EjetuQo+vkCJmnijH9pdkUwK8OYgZr5g759Fa9Gx0BkxwhNBWjb+BwMU+6N/F6V4489F4CpnTkzpmUTUACM2d/ZvgykKN3G4UjZK5VZ0nnyHjHyRwR82nsmEZo/JbqbWNR3vGtuENlk3aIYmLvJIkzT6WIxWHkqgZ/K16md4hLR6YcLTA7elols4TRAAbz99JG+f70N+Zog8P+PEtMvkNE709jM6evq512spynrJPmadrJwhExYY86f62/IlP/38XvHSHSzExITKOsvF8vUjbNdxw5op2MUGKmiMdcftnzXaR5onaH+0hn0zFHyMxGHEfqD1mm0x13Rjoi73TmXTNpAu3wLqYc6WzqXedtzpGaJ/Xu6ptYjnadPPOLDI68AerMTJuD/f4rXJ2/Q4hJe8nduJPv6BxV6c7++BVvusPg6JLQDkx15h0dJSzGovHFKjSCHC0ye3fKZpLYsVj0vmydEpMjetuQI2wde8+ZinZdNGbQLLF2REy+68hREuo8ml/fDrmxThc54o7On0+eKhP7+69koRaV1dubrs1bt7b6nvRN0rx7ib+jkbKsPbuMFWf+isF78rQ9Msf6rz+exSvRp1vH8fWTJa1aLWmyuo3ax86UNV7MP/yjnw+oLHzaPRx/AAAAAElFTkSuQmCC";
const _sfc_main$1 = {
  name: "Footer",
  data() {
    return {
      currentYear: (/* @__PURE__ */ new Date()).getFullYear()
    };
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_router_link = resolveComponent("router-link");
  _push(`<footer${ssrRenderAttrs(mergeProps({ class: "bg-off-white footer" }, _attrs))}><div class="footer-shapes"><div class="footer-shape"><img${ssrRenderAttr("src", _imports_0)} alt="shape"></div><div class="footer-shape footer-round-shape"><img${ssrRenderAttr("src", _imports_1)} alt="shape"></div></div><div class="footer-upper pt-100 pb-80 position-relative"><div class="container"><div class="row"><div class="col-sm-12 col-md-6 col-lg-3"><div class="footer-content-item"><div class="footer-logo">`);
  _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<img${ssrRenderAttr("src", _imports_2$2)} alt="logo"${_scopeId}>`);
      } else {
        return [
          createVNode("img", {
            src: _imports_2$2,
            alt: "logo"
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><div class="footer-details"><p>Matter AI Automation and Developer Services</p><ul class="social-list social-list-btn"><li><a href="https://www.facebook.com/" target="_blank"><i class="icofont-facebook"></i></a></li><li><a href="https://twitter.com/" target="_blank"><i class="icofont-twitter"></i></a></li><li><a href="https://www.instagram.com/" target="_blank"><i class="icofont-instagram"></i></a></li><li><a href="https://www.pinterest.com/" target="_blank"><i class="icofont-pinterest"></i></a></li></ul></div></div></div><div class="col-sm-6 col-md-6 col-lg-3"><div class="footer-content-list footer-content-item desk-pad-left-70"><div class="footer-content-title"><h3>Useful Links</h3></div><ul class="footer-details footer-list"><li>`);
  _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`About Us`);
      } else {
        return [
          createTextVNode("About Us")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li>`);
  _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`News &amp; Blogs`);
      } else {
        return [
          createTextVNode("News & Blogs")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li>`);
  _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Services`);
      } else {
        return [
          createTextVNode("Services")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li>`);
  _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Products`);
      } else {
        return [
          createTextVNode("Products")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li>`);
  _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Our Pricing`);
      } else {
        return [
          createTextVNode("Our Pricing")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li>`);
  _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Contact`);
      } else {
        return [
          createTextVNode("Contact")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li></ul></div></div><div class="col-sm-6 col-md-6 col-lg-3"><div class="footer-content-list footer-content-item desk-pad-left-70"><div class="footer-content-title"><h3>Services</h3></div><ul class="footer-details footer-list"><li>`);
  _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Robotic Automation`);
      } else {
        return [
          createTextVNode("Robotic Automation")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li>`);
  _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Predictive Analysis`);
      } else {
        return [
          createTextVNode("Predictive Analysis")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li>`);
  _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Deep Learning`);
      } else {
        return [
          createTextVNode("Deep Learning")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li>`);
  _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Statistic Modeling`);
      } else {
        return [
          createTextVNode("Statistic Modeling")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li>`);
  _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Data Mining`);
      } else {
        return [
          createTextVNode("Data Mining")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li>`);
  _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Security &amp; Surveillance`);
      } else {
        return [
          createTextVNode("Security & Surveillance")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li></ul></div></div><div class="col-sm-6 col-md-6 col-lg-3"><div class="footer-content-list footer-content-item desk-pad-left-70"><div class="footer-content-title"><h3>Contact</h3></div><div class="footer-details footer-address"><div class="footer-address-item"><div class="footer-address-text"><h4>Phone:</h4><p><a href="tel:+6281703106180">(+62) 817 031 06180</a></p></div></div><div class="footer-address-item"><div class="footer-address-text"><h4>Email:</h4><p><a href="mailto:info@matter.co.id">info@matter.co.id</a></p></div></div><div class="footer-address-item"><div class="footer-address-text"><h4>Address:</h4><p>Pondok Indah Office Tower 3 Fl.17, Jakarta Selatan, Indonesia</p></div></div></div></div></div></div></div></div><div class="footer-lower bg-blue position-relative"><div class="container"><div class="footer-copyright-text footer-copyright-text-white"><p>Copyright \xA9${ssrInterpolate($data.currentYear)} Matter.</p></div></div></div></footer>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Footer.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_10 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useRoute();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Navbar = __nuxt_component_0;
      const _component_MainBanner = __nuxt_component_1;
      const _component_Feature = __nuxt_component_2;
      const _component_About = __nuxt_component_3;
      const _component_Services = __nuxt_component_4;
      const _component_FreeTrial = __nuxt_component_5;
      const _component_Process = __nuxt_component_6;
      const _component_Testimonial = __nuxt_component_7;
      const _component_Blog = __nuxt_component_8;
      const _component_Newsletter = __nuxt_component_9;
      const _component_Footer = __nuxt_component_10;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_Navbar, null, null, _parent));
      _push(ssrRenderComponent(_component_MainBanner, null, null, _parent));
      _push(ssrRenderComponent(_component_Feature, null, null, _parent));
      _push(ssrRenderComponent(_component_About, null, null, _parent));
      _push(ssrRenderComponent(_component_Services, null, null, _parent));
      _push(ssrRenderComponent(_component_FreeTrial, null, null, _parent));
      _push(ssrRenderComponent(_component_Process, null, null, _parent));
      _push(ssrRenderComponent(_component_Testimonial, null, null, _parent));
      _push(ssrRenderComponent(_component_Blog, { class: "bg-off-white" }, null, _parent));
      _push(ssrRenderComponent(_component_Newsletter, null, null, _parent));
      _push(ssrRenderComponent(_component_Footer, null, null, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-4dea072c.mjs.map
