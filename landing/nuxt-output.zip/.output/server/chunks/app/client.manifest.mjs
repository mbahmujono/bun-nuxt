const client_manifest = {
  "_vue.f36acd1f.1d5b94ed.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vue.f36acd1f.1d5b94ed.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "assets/images/blogs/blog-1.jpg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/jpeg",
    "file": "blog-1.fdc6778b.jpg",
    "src": "assets/images/blogs/blog-1.jpg"
  },
  "assets/images/blogs/blog-2.jpg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/jpeg",
    "file": "blog-2.4961c893.jpg",
    "src": "assets/images/blogs/blog-2.jpg"
  },
  "assets/images/blogs/blog-3.jpg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/jpeg",
    "file": "blog-3.83ad3c97.jpg",
    "src": "assets/images/blogs/blog-3.jpg"
  },
  "assets/images/feature-shape/feature-shape-1.png": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png",
    "file": "feature-shape-1.6c92c64a.png",
    "src": "assets/images/feature-shape/feature-shape-1.png"
  },
  "assets/images/frame-1.png": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png",
    "file": "frame-1.16b97bef.png",
    "src": "assets/images/frame-1.png"
  },
  "assets/images/homepage-one/header-bg-shape.png": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png",
    "file": "header-bg-shape.716a8c3c.png",
    "src": "assets/images/homepage-one/header-bg-shape.png"
  },
  "assets/images/homepage-one/header-shape.png": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png",
    "file": "header-shape.27181357.png",
    "src": "assets/images/homepage-one/header-shape.png"
  },
  "assets/images/homepage-three/bg.jpg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/jpeg",
    "file": "bg.a52fef59.jpg",
    "src": "assets/images/homepage-three/bg.jpg"
  },
  "assets/images/logo-white.png": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png",
    "file": "logo-white.4323b759.png",
    "src": "assets/images/logo-white.png"
  },
  "assets/images/logo.png": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png",
    "file": "logo.fe4a280d.png",
    "src": "assets/images/logo.png"
  },
  "assets/images/page-bg/page-bg-1.jpg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/jpeg",
    "file": "page-bg-1.868e1aec.jpg",
    "src": "assets/images/page-bg/page-bg-1.jpg"
  },
  "assets/images/page-bg/page-bg-2.jpg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/jpeg",
    "file": "page-bg-2.cde76a89.jpg",
    "src": "assets/images/page-bg/page-bg-2.jpg"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-404.95c28eb4.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-404.868a9609.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_vue.f36acd1f.1d5b94ed.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.95c28eb4.css": {
    "file": "error-404.95c28eb4.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-500.e798523c.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-500.d0e6ea88.js",
    "imports": [
      "_vue.f36acd1f.1d5b94ed.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.e798523c.css": {
    "file": "error-500.e798523c.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.6d6de73d.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "assets": [
      "logo.fe4a280d.png",
      "logo-white.4323b759.png",
      "header-shape.27181357.png",
      "feature-shape-1.6c92c64a.png",
      "blog-1.fdc6778b.jpg",
      "blog-2.4961c893.jpg",
      "blog-3.83ad3c97.jpg"
    ],
    "file": "index.53df1ec6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "logo.fe4a280d.png": {
    "file": "logo.fe4a280d.png",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png"
  },
  "logo-white.4323b759.png": {
    "file": "logo-white.4323b759.png",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png"
  },
  "header-shape.27181357.png": {
    "file": "header-shape.27181357.png",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png"
  },
  "feature-shape-1.6c92c64a.png": {
    "file": "feature-shape-1.6c92c64a.png",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png"
  },
  "blog-1.fdc6778b.jpg": {
    "file": "blog-1.fdc6778b.jpg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/jpeg"
  },
  "blog-2.4961c893.jpg": {
    "file": "blog-2.4961c893.jpg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/jpeg"
  },
  "blog-3.83ad3c97.jpg": {
    "file": "blog-3.83ad3c97.jpg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/jpeg"
  },
  "pages/index123.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index123.c729540e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index123.vue"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
